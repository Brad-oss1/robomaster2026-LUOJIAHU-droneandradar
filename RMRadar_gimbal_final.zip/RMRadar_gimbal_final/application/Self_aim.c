#include "Self_aim.h"
#include "main.h"
#include "usart.h"
#include "CRC8_CRC16.h"
#include "string.h"
#include "cmsis_os.h"
#include "gimbal_task.h"
#include "INS_task.h"
#include "usbd_cdc_if.h"
#include "dm_imu.h"
#include "gimbal_behaviour.h"
#include "CAN_receive.h"
static uint8_t buffer[sizeof(RECEIVE_DATA)];//���ڴ洢���������ݰ�
//uint8_t Usart_Receive[1];//���ڽ��յ����ֽڵ�����
//uint8_t Usart_Receive[14];
static uint16_t received = 0;//��ǰ���յ������ݳ���
static uint8_t Count=0;//����״̬��ǩ
InputData inputdata;
SEND_DATA Send_Data;
extern __IO uint32_t uwTick;
uint32_t sendTick =0;
gimbal_control_t *gimbal_data;
uint32_t now;

//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
//{
//    if (huart == &huart6)
//    {
//        uint8_t received_byte = Usart_Receive[0]; // ��ȡ���յ����ֽ�
//        // buffer_single = received_byte;
//        // ��ȡ���ֽڣ�����Ƿ�Ϊ֡ͷ��sof
//        if (Count == 0)
//        {
//            if (received_byte == FRAME_HEADER_S)
//            {
//                buffer[received++] = received_byte; // �洢֡ͷ��ʼ��־
//                Count = 1;                          // ����֡ͷ���ս׶�
//            }
//            else
//            {
//                received = 0; // ����֡ͷ��־��������
//            } 
//        }
//        else if (Count == 1) 
//        {
//            buffer[received++] = received_byte;

//            // ���֡ͷ�Ƿ�������
//            if (received == sizeof(FrameHeader))
//            {
//                FrameHeader *header = (FrameHeader *)buffer;

//                // ���sof��crc8�Ƿ���Ϲ̶�ֵ
//                if (header->s == FRAME_HEADER_S && header->p == FRAME_HEADER_P)
//                {
//                    Count = 2; // ֡ͷУ��ͨ����׼���������ݲ���
//                }
//                else
//                {
//                    received = 0; // ֡ͷ��ƥ�䣬���ý���
//                    Count = 0;
//                }
//            }
//        }
//        else if (Count == 2) // �������ݲ����Լ�֡β
//        {
//            buffer[received++] = received_byte;

//            // ������ݰ��Ƿ��������
//            if (received == sizeof(FrameHeader) + sizeof(InputData) + sizeof(FrameTailer))
//            {
//                FrameTailer *tail = (FrameTailer *)(buffer + sizeof(FrameHeader) + sizeof(InputData));

//                // ���֡β
//                if (verify_CRC16_check_sum((uint8_t *)buffer, sizeof(RECEIVE_DATA)))
//                {
//                    // ���ݰ�����ɹ����������ݲ���
//                    memcpy(&inputdata, buffer + sizeof(FrameHeader), sizeof(InputData));
//                }

//                // �����Ƿ�У��ɹ��������ý���״̬
//                received = 0;
//                Count = 0;
//            }
//        }
//        // ���¿�ʼ����
//        HAL_UART_Receive_IT(&huart6, (uint8_t *)Usart_Receive, 1);
//    }
//}
void Protocol_FeedByte(uint8_t received_byte)//通信协议函数
{
    if (Count == 0)
    {
        if (received_byte == FRAME_HEADER_S)
        {
            buffer[received++] = received_byte;
            Count = 1;
        }
        else
        {
            received = 0;
        }
    }
    else if (Count == 1)
    {
        buffer[received++] = received_byte;

        if (received == sizeof(FrameHeader))
        {
            FrameHeader *header = (FrameHeader *)buffer;

            if (header->s == FRAME_HEADER_S &&
                header->p == FRAME_HEADER_P)
            {
                Count = 2;
            }
            else
            {
                received = 0;
                Count = 0;
            }
        }
    }
    else if (Count == 2)
    {
        buffer[received++] = received_byte;

        if (received == sizeof(RECEIVE_DATA))
        {
            if (verify_CRC16_check_sum(buffer, sizeof(RECEIVE_DATA)))
            {
                memcpy(&inputdata,
                       buffer + sizeof(FrameHeader),
                       sizeof(InputData));
            }

            received = 0;
            Count = 0;
        }
    }
}

void data_transition(void)
{
    uint8_t enemy_color;
    get_enemy_color(&enemy_color);
    Send_Data.frame_header.s = FRAME_HEADER_S; 
    Send_Data.frame_header.p = FRAME_HEADER_P;
    gimbal_data = get_gimbal_data();
    Send_Data.output_data.q[0] = imu.q[0];
    Send_Data.output_data.q[1] = imu.q[1];
    Send_Data.output_data.q[2] = imu.q[2];
    Send_Data.output_data.q[3] = imu.q[3];
    Send_Data.output_data.yaw = gimbal_data->gimbal_yaw_motor.absolute_angle;
    Send_Data.output_data.yaw_vel = 0;
    Send_Data.output_data.pitch = gimbal_data->gimbal_pitch_motor.absolute_angle;
    Send_Data.output_data.pitch_vel = 0;
	Send_Data.output_data.running_time = now - init_end;

    uint8_t *data_ptr = (uint8_t *)&Send_Data;                                    
    uint32_t data_length = sizeof(SEND_DATA) - sizeof(Send_Data.frame_tailer.crc16); 
    Send_Data.frame_tailer.crc16 = get_CRC16_check_sum(data_ptr, data_length, FRAME_TAILER_CRC16_init);
}

void Usbd_SEND(void)
{
    if (uwTick - sendTick < 30)//30ms发一次
        return;
    data_transition();
    sendTick = uwTick;
    uint8_t *data_ptr = (uint8_t *)&Send_Data;
    uint16_t data_length = sizeof(SEND_DATA);
    // uint8_t newline = '\n';
	if (CDC_Transmit_FS(data_ptr, data_length) == USBD_BUSY)
    {
		//BUSY就放弃
        // 可选：记录丢包、计数、重试
    }
}

void Self_aim_task(void const *pvParameters)
{
//	HAL_UART_Receive_IT(&huart6, (uint8_t *)Usart_Receive, 1);
	while(1)
	{
		now = HAL_GetTick();
		Usbd_SEND();
		osDelay(30);
	}
}

InputData *get_selfaim_data()
{
	return &inputdata;
}

void LowPassFilter_Init(LowPassFilter_t *filter, float Ts,float CutoffFreq)
{
    filter->output = 0.0f;
    filter->alpha = (2*PI*CutoffFreq*Ts)/(1+2*PI*CutoffFreq*Ts);
}

float LowPassFilter_Update(LowPassFilter_t *filter, float input)
{
    filter->output += filter->alpha * (input - filter->output);
    return filter->output;
}
