/**
  ****************************(C) COPYRIGHT 2019 DJI****************************
  * @file       can_receive.c/h
  * @brief      there is CAN interrupt function  to receive motor data,
  *             and CAN send function to send motor current to control motor.
  *             ������CAN�жϽ��պ��������յ������,CAN���ͺ������͵���������Ƶ��.
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-26-2018     RM              1. done
  *  V1.1.0     Nov-11-2019     RM              1. support hal lib
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2019 DJI****************************
  */

#ifndef CAN_RECEIVE_H
#define CAN_RECEIVE_H

#include "struct_typedef.h"
#include "user_lib.h"
#define CHASSIS_CAN hcan2
#define GIMBAL_CAN hcan1

#define P_MIN   -12.5  
#define P_MAX   12.5   
#define V_MIN   -30.0    
#define V_MAX   30.0     
#define KP_MIN  0      
#define KP_MAX  500    
#define KD_MIN  0      
#define KD_MAX  5      
#define Tor_MIN   -18.0f  
#define Tor_MAX   18.0f

extern CAN_HandleTypeDef hcan1;
extern CAN_HandleTypeDef hcan2;

/* CAN send and receive ID */
typedef enum
{
    CAN_CHASSIS_ALL_ID = 0x200,
    CAN_FRICTION_LEFT_ID = 0x201,//CAN_3508_M1_ID
    CAN_FRICTION_RIGHT_ID = 0x202,//CAN_3508_M2_ID
    CAN_3508_M3_ID = 0x203,
    CAN_3508_M4_ID = 0x204,
	
    CAN_YAW_MOTOR_ID = 0x205,
    CAN_PIT_MOTOR_ID = 0x206,
	CAN_TRIGGER_MOTOR_ID = 0x207,
    CAN_GIMBAL_ALL_ID = 0x1FF,
    
	
	CAN_DM_CLEAR_ERROR_ID = 0x7FF,
	
	CAN_gmbial_chassis_data1=0x01,
	CAN_gmbial_chassis_data2=0x02,
	CAN_gmbial_chassis_data3=0x03,
	CAN_gimbal_chassis_data4=0x04,
	CAN_referee_data=0x05,
	
	
	CAN_DM_IMU_ID = 0x11,
	
} can_msg_id_e;
//union for folat
typedef union
{
	float float_t;
	uint8_t uint8_t[4];
} send_float_typedef;
typedef struct
{
	float vx_set;//����x�᷽���趨���ٶȿ�������
	float vy_set;//����y�᷽���趨���ٶȿ�����
	float wz_set;//��������ʱ �趨���ٶȿ�������
	float yaw_angle;//yaw��Ƕ�ʵʱֵ
	float yawangle_set;//yaw��Ƕ��趨ֵ
	float yaw_gyro;//yaw����ٶ�ʵʱֵ
	first_order_filter_type_t chassis_cmd_slow_set_vx;  //use first order filter to slow set-point.ʹ��һ�׵�ͨ�˲������趨ֵ
	first_order_filter_type_t chassis_cmd_slow_set_vy;  //use first order filter to slow set-point.ʹ��һ�׵�ͨ�˲������趨ֵ

	uint16_t chassis_mode;//����ģʽ
	uint16_t shoot_mode;//���ģʽ
}chassis_data_t;
//rm motor data
typedef struct
{
    uint16_t ecd;
    int16_t speed_rpm;
    int16_t given_current;
    uint8_t temperate;
    int16_t last_ecd;
} motor_measure_t;
//
typedef struct
{
    uint8_t ID;
	uint8_t state;
	int p_int;
    int v_int;
    int t_int;
    float pos;
    float vel;
    float tor;
    uint16_t torque;
    uint8_t mos_temperate;
	uint8_t rotor_temperate;
} dm_motor_measure_t;


/**
  * @brief          send control current of motor (0x205, 0x206, 0x207, 0x208)
  * @param[in]      yaw: (0x205) 6020 motor control current, range [-30000,30000] 
  * @param[in]      pitch: (0x206) 6020 motor control current, range [-30000,30000]
  * @param[in]      shoot: (0x207) 2006 motor control current, range [-10000,10000]
  * @param[in]      rev: (0x208) reserve motor control current
  * @retval         none
  */

extern void CAN_cmd_gimbal(int16_t yaw, int16_t pitch, int16_t shoot, int16_t rev);
extern void CAN_clear_dm_error(void);
extern void CAN_dm_enable(void);
extern void pos_sped_ctrl(float p_des,float v_limit);
extern void MIT_CtrlMotor(float _pos, float _vel,float _KP, float _KD, float _torq);
extern void CAN_dm_save_0_point(void);

extern float uint_to_float(int x_int, float x_min, float x_max, int bits);
extern int float_to_uint(float x, float x_min, float x_max, int bits);

/**
  * @brief          send CAN packet of ID 0x700, it will set chassis motor 3508 to quick ID setting
  * @param[in]      none
  * @retval         none
  */
/**
  * @brief          ����IDΪ0x700��CAN��,��������3508��������������ID
  * @param[in]      none
  * @retval         none
  */
extern void CAN_cmd_chassis_reset_ID(void);

/**
  * @brief          send control current of motor (0x201, 0x202, 0x203, 0x204)
  * @param[in]      motor1: (0x201) 3508 motor control current, range [-16384,16384] 
  * @param[in]      motor2: (0x202) 3508 motor control current, range [-16384,16384] 
  * @param[in]      motor3: (0x203) 3508 motor control current, range [-16384,16384] 
  * @param[in]      motor4: (0x204) 3508 motor control current, range [-16384,16384] 
  * @retval         none
  */
extern void CAN_cmd_chassis(int16_t motor1, int16_t motor2, int16_t motor3, int16_t motor4);
/**
  * @brief          ���͵����ٶ��趨ֵvxvy
  * @param[in]      none
  * @retval         none
  */
  
extern void can_gimbal_chassis_data1(chassis_data_t *chassis_data);
extern void can_gimbal_chassis_data2(chassis_data_t *chassis_data);
extern void can_gimbal_chassis_data3(chassis_data_t *chassis_data);
extern void can_gimbal_chassis_data4(chassis_data_t *chassis_data);


/**
* @brief          达妙电机控制
  * @param[in]      none
  * @retval         none
  */
void MIT_CtrlMotor(float _pos, float _vel,float _KP, float _KD, float _torq);
	

extern const motor_measure_t *get_yaw_gimbal_motor_measure_point(void);

extern const motor_measure_t *get_pitch_gimbal_motor_measure_point(void);

extern const motor_measure_t *get_left_friction_motor_measure_point(void);

extern const motor_measure_t *get_right_friction_motor_measure_point(void);

extern const motor_measure_t *get_trigger_motor_measure_point(void);
	
/**
  * @brief          return the chassis 3508 motor data point
  * @param[in]      i: motor number,range [0,3]
  * @retval         motor data point
  */
extern const motor_measure_t *get_chassis_motor_measure_point(uint8_t i);

extern void get_enemy_color(uint8_t *enemy_color);
#endif
