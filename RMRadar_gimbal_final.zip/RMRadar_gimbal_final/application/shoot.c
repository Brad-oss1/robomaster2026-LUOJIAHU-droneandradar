#include "main.h"
#include "shoot.h"
#include "bsp_laser.h"
#include "bsp_fric.h"
#include "CAN_receive.h"
#include "pid.h"
#include "detect_task.h"
#include "arm_math.h"

shoot_control_t shoot_control;

void trigger_control_set(void);
void shoot_feedback_update(void);
void shoot_set_mode(void);
void shoot_control_set(void);
static void trigger_motor_turn_back(void);
void trigger_control(void);

void shoot_Init()
{
	static const fp32 friction_speed_pid[3]={FRICTION_SPEED_PID_KP ,FRICTION_SPEED_PID_KI,FRICTION_SPEED_PID_KD};
	static const fp32 friction_current_pid[3]={FRICTION_CURRENT_PID_KP,FRICTION_CURRENT_PID_KI,FRICTION_CURRENT_PID_KD};
	PID_init(&shoot_control.friction_left_motor_speed_pid,PID_POSITION,friction_speed_pid,FRICTION_SPEED_PID_MAX_OUT,FRICTION_SPEED_PID_MAX_IOUT);
	PID_init(&shoot_control.friction_left_motor_current_pid,PID_POSITION,friction_current_pid,FRICTION_CURRENT_PID_MAX_OUT,FRICTION_CURRENT_PID_MAX_IOUT);
	PID_init(&shoot_control.friction_right_motor_speed_pid,PID_POSITION,friction_speed_pid,FRICTION_SPEED_PID_MAX_OUT,FRICTION_SPEED_PID_MAX_IOUT);
	PID_init(&shoot_control.friction_right_motor_current_pid,PID_POSITION,friction_current_pid,FRICTION_CURRENT_PID_MAX_OUT,FRICTION_CURRENT_PID_MAX_IOUT);
	
	static const fp32 Trigger_speed_pid[3] = {TRIGGER_ANGLE_PID_KP, TRIGGER_ANGLE_PID_KI, TRIGGER_ANGLE_PID_KD};
	PID_init(&shoot_control.trigger_motor_pid, PID_POSITION, Trigger_speed_pid, TRIGGER_READY_PID_MAX_OUT, TRIGGER_READY_PID_MAX_IOUT);

	shoot_control.shoot_mode= SHOOT_STOP;
	ramp_init(&shoot_control.fric_ramp,SHOOT_CONTROL_TIME * 0.001f,FRICTION_SPEED_MAX,FRICTION_SPEED_MIN);
	//rc data get
	shoot_control.shoot_rc = get_remote_control_point();
	shoot_control.trigger_motor_measure = get_trigger_motor_measure_point();
	
	shoot_control.friction_motor_measure[0]=get_left_friction_motor_measure_point();
	shoot_control.friction_motor_measure[1]=get_right_friction_motor_measure_point();
	
    shoot_control.angle = shoot_control.trigger_motor_measure->ecd * MOTOR_ECD_TO_ANGLE;
    shoot_control.trigger_given_current = 0;

    shoot_control.set_angle = shoot_control.angle;
	///init 2006motor speed is zero
    shoot_control.trigger_speed = 0.0f;
    shoot_control.trigger_speed_set = 0.0f;
	
}
void shoot_feedback_update()
{
    static fp32 speed_fliter_1 = 0.0f;
    static fp32 speed_fliter_2 = 0.0f;
    static fp32 speed_fliter_3 = 0.0f;

    //拨弹轮电机速度滤波一下
    static const fp32 fliter_num[3] = {1.725709860247969f, -0.75594777109163436f, 0.030237910843665373f};

    //二阶低通滤波
    speed_fliter_1 = speed_fliter_2;
    speed_fliter_2 = speed_fliter_3;
    speed_fliter_3 = speed_fliter_2 * fliter_num[0] + speed_fliter_1 * fliter_num[1] + (shoot_control.trigger_motor_measure->speed_rpm * MOTOR_RPM_TO_SPEED) * fliter_num[2];
    shoot_control.trigger_speed = speed_fliter_3;
	
	//rc data get	
	shoot_control.shoot_rc = get_remote_control_point();
	shoot_control.trigger_motor_measure = get_trigger_motor_measure_point();
	
	shoot_control.friction_motor_measure[0]=get_left_friction_motor_measure_point();
	shoot_control.friction_motor_measure[1]=get_right_friction_motor_measure_point();
	
	
	shoot_control.friction_left_speed=shoot_control.friction_motor_measure[0]->speed_rpm;
	shoot_control.friction_right_speed=shoot_control.friction_motor_measure[1]->speed_rpm;
	
	shoot_control.last_press_l=shoot_control.press_l;
	shoot_control.last_press_r=shoot_control.press_r;
	shoot_control.press_l=shoot_control.shoot_rc->mouse.press_l;
	shoot_control.press_r=shoot_control.shoot_rc->mouse.press_r;
}

void shoot_set_mode()
{
	static int8_t last_s = RC_SW_DOWN;
	
	//不同档对应stop single continue
    if ((switch_is_up(shoot_control.shoot_rc->rc.s[SHOOT_RC_MODE_CHANNEL]) && !switch_is_up(last_s) ))
    {
        shoot_control.shoot_mode = SHOOT_BULLET_CONTINUE;
    }
    else if ((switch_is_mid(shoot_control.shoot_rc->rc.s[SHOOT_RC_MODE_CHANNEL]) && !switch_is_mid(last_s) ))
    {
        shoot_control.shoot_mode = SHOOT_BULLET_SINGLE;
    }
	else if ((switch_is_down(shoot_control.shoot_rc->rc.s[SHOOT_RC_MODE_CHANNEL]) && !switch_is_down(last_s) ))
	{
        shoot_control.shoot_mode = SHOOT_STOP;
    }
	
	last_s = shoot_control.shoot_rc->rc.s[SHOOT_RC_MODE_CHANNEL];
}


void shoot_control_set()
{
	if(shoot_control.shoot_mode==SHOOT_STOP)
	{
		laser_off();
		shoot_control.trigger_speed_set = 0;
		shoot_control.friction_speed_set = 0;
	}
	else if(shoot_control.shoot_mode==SHOOT_BULLET_SINGLE)
	{
		laser_on();
		shoot_control.friction_speed_set = 8500.0f;
		shoot_control.trigger_speed_set = 0;
	}
	else if(shoot_control.shoot_mode==SHOOT_BULLET_CONTINUE)
	{
		laser_on();
		shoot_control.trigger_speed_set = CONTINUE_TRIGGER_SPEED;
        trigger_motor_turn_back();
		
		shoot_control.friction_speed_set = 8500.0f;
	}
	
}

void trigger_control()
{
	PID_calc(&shoot_control.trigger_motor_pid, shoot_control.trigger_speed, shoot_control.trigger_speed_set);
    shoot_control.trigger_given_current = (int16_t)(shoot_control.trigger_motor_pid.out);
}

void friction_control(void)
{
    // 左摩擦轮
    PID_calc(&shoot_control.friction_left_motor_speed_pid,
             shoot_control.friction_left_speed,
             -shoot_control.friction_speed_set);//left -
    shoot_control.friction_left_given_current = PID_calc(
             &shoot_control.friction_left_motor_current_pid,
             shoot_control.friction_motor_measure[0]->given_current,
             shoot_control.friction_left_motor_speed_pid.out);

    // 右摩擦轮
    PID_calc(&shoot_control.friction_right_motor_speed_pid,
             shoot_control.friction_right_speed,
            +shoot_control.friction_speed_set);//right +
    shoot_control.friction_right_given_current = PID_calc(
             &shoot_control.friction_right_motor_current_pid,
             shoot_control.friction_motor_measure[1]->given_current,
             shoot_control.friction_right_motor_speed_pid.out);
}


static void trigger_motor_turn_back(void)
{
    if( shoot_control.block_time < BLOCK_TIME)
    {
        shoot_control.trigger_speed_set = shoot_control.trigger_speed_set;
    }
    else
    {
        shoot_control.trigger_speed_set = -shoot_control.trigger_speed_set;
    }

    if(fabs(shoot_control.trigger_speed) < BLOCK_TRIGGER_SPEED && shoot_control.block_time < BLOCK_TIME)
    {
        shoot_control.block_time++;
        shoot_control.reverse_time = 0;
    }
    else if (shoot_control.block_time == BLOCK_TIME && shoot_control.reverse_time < REVERSE_TIME)
    {
        shoot_control.reverse_time++;
    }
    else
    {
        shoot_control.block_time = 0;
    }
}

void shoot_speed_filter()
{
	
}

const shoot_control_t *shoot_control_loop()
{
	shoot_feedback_update();
	shoot_set_mode();
	shoot_control_set();
	friction_control();
	trigger_control();
//	shoot_speed_filter();
	return &shoot_control;
}
