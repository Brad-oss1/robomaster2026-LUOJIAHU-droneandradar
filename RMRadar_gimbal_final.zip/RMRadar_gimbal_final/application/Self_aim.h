#ifndef __SELF_AIM_H__
#define __SELF_AIM_H__

#include "struct_typedef.h"
#include "main.h"
typedef struct {
    uint8_t     mode;
    float       q[4];
    float       yaw;
    float       yaw_vel;
    float       pitch;
    float       pitch_vel;
    float       bullet_speed;
    uint16_t    bullet_count;
	uint32_t    running_time;

} __attribute__((packed)) OutputData;


typedef struct {
    uint8_t       mode;
    float         yaw;
    float         yaw_vel;
    float         yaw_acc;
    float         pitch;
    float         pitch_vel;
    float         pitch_acc;
} __attribute__((packed)) InputData;

typedef struct  {
    uint8_t     s;
    uint8_t     p;
} __attribute__((packed))FrameHeader;

typedef struct {
    uint16_t    crc16;
} __attribute__((packed))FrameTailer ;

typedef struct  {            
    FrameHeader frame_header;
    InputData   input_data;
    FrameTailer frame_tailer;   
} __attribute__((packed))RECEIVE_DATA;

typedef struct  {         
    FrameHeader frame_header;
    OutputData  output_data;
    FrameTailer frame_tailer;
	
} __attribute__((packed))SEND_DATA;

typedef struct
{
    float output;   // 滤波后的输出
    float alpha;    // 滤波系数，0~1之间
} LowPassFilter_t;

#define RECEIVE_DATA_SIZE 12
#define SEND_DATA_SIZE 19
#define FRAME_HEADER      0X7B //Frame_header 
#define FRAME_TAIL        0X7D //Frame_tail 

#define FRAME_HEADER_S  'S'
#define FRAME_HEADER_P  'P'  
// #define FRAME_HEADER_SOF  0xA5  
#define FRAME_HEADER_CRC8 0xFF  
#define FRAME_TAILER_CRC16_init 0xFFFF  
void Self_aim_task(void const *pvParameters);
InputData *get_selfaim_data(void);
extern InputData inputdata;

extern void Protocol_FeedByte(uint8_t received_byte);//通信协议函数
void LowPassFilter_Init(LowPassFilter_t *filter, float Ts,float CutoffFreq);
float LowPassFilter_Update(LowPassFilter_t *filter, float input);


#endif
