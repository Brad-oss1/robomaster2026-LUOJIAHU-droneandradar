#ifndef __FILTER_H__
#define __FILTER_H__


//low_pass_filter
typedef struct
{
    float output;   // 滤波后的输出
    float alpha;    // 滤波系数，0~1之间
} LowPassFilter_t;

float LowPassFilter_Update(LowPassFilter_t *filter, float input);
void LowPassFilter_Init(LowPassFilter_t *filter, float alpha);



#endif