#include "main.h"
#include "cmsis_os.h"
#include "CAN_task.h"
#include "can.h"
#include "CAN_receive.h"
#include "gimbal_task.h"

void can_task(void const *pvParameters)
{
	chassis_data_t *chassis_data;
	chassis_data= get_chassis_data_point();
	while(1)
	{

		osDelay(10);
	}
}

