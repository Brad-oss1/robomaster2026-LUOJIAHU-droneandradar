//
// Created by RM UI Designer
// Static Edition
//

#ifndef UI_H
#define UI_H
#ifdef __cplusplus
extern "C" {
#endif

#include "ui_interface.h"

#include "ui_g.h"

void ui_init_g_Self_aim();
void ui_update_g_Self_aim();
void ui_remove_g_Self_aim();
void ui_init_g_Shoot_status();
void ui_update_g_Shoot_status();
void ui_remove_g_Shoot_status();
void ui_init_g_Static_act();
void ui_update_g_Static_act();
void ui_remove_g_Static_act();

#ifdef __cplusplus
}
#endif

#endif // UI_H
