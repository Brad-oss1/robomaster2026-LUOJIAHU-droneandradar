//
// Created by RM UI Designer
// Static Edition
//

#include <string.h>

#include "ui_interface.h"

ui_1_frame_t ui_g_Self_aim_0;

ui_interface_round_t *ui_g_Self_aim_Self_aim_Flag = (ui_interface_round_t*)&(ui_g_Self_aim_0.data[0]);

void _ui_init_g_Self_aim_0() {
    for (int i = 0; i < 1; i++) {
        ui_g_Self_aim_0.data[i].figure_name[0] = 0;
        ui_g_Self_aim_0.data[i].figure_name[1] = 0;
        ui_g_Self_aim_0.data[i].figure_name[2] = i + 0;
        ui_g_Self_aim_0.data[i].operate_type = 1;
    }
    for (int i = 1; i < 1; i++) {
        ui_g_Self_aim_0.data[i].operate_type = 0;
    }

    ui_g_Self_aim_Self_aim_Flag->figure_type = 2;
    ui_g_Self_aim_Self_aim_Flag->operate_type = 1;
    ui_g_Self_aim_Self_aim_Flag->layer = 0;
    ui_g_Self_aim_Self_aim_Flag->color = 7;
    ui_g_Self_aim_Self_aim_Flag->start_x = 217;
    ui_g_Self_aim_Self_aim_Flag->start_y = 643;
    ui_g_Self_aim_Self_aim_Flag->width = 10;
    ui_g_Self_aim_Self_aim_Flag->r = 18;


    ui_proc_1_frame(&ui_g_Self_aim_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Self_aim_0, sizeof(ui_g_Self_aim_0));
}

void _ui_update_g_Self_aim_0() {
    for (int i = 0; i < 1; i++) {
        ui_g_Self_aim_0.data[i].operate_type = 2;
    }

    ui_proc_1_frame(&ui_g_Self_aim_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Self_aim_0, sizeof(ui_g_Self_aim_0));
}

void _ui_remove_g_Self_aim_0() {
    for (int i = 0; i < 1; i++) {
        ui_g_Self_aim_0.data[i].operate_type = 3;
    }

    ui_proc_1_frame(&ui_g_Self_aim_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Self_aim_0, sizeof(ui_g_Self_aim_0));
}

ui_string_frame_t ui_g_Self_aim_1;
ui_interface_string_t* ui_g_Self_aim_NewText = &(ui_g_Self_aim_1.option);

void _ui_init_g_Self_aim_1() {
    ui_g_Self_aim_1.option.figure_name[0] = 0;
    ui_g_Self_aim_1.option.figure_name[1] = 0;
    ui_g_Self_aim_1.option.figure_name[2] = 1;
    ui_g_Self_aim_1.option.operate_type = 1;

    ui_g_Self_aim_NewText->figure_type = 7;
    ui_g_Self_aim_NewText->operate_type = 1;
    ui_g_Self_aim_NewText->layer = 0;
    ui_g_Self_aim_NewText->color = 3;
    ui_g_Self_aim_NewText->start_x = 116;
    ui_g_Self_aim_NewText->start_y = 709;
    ui_g_Self_aim_NewText->width = 3;
    ui_g_Self_aim_NewText->font_size = 30;
    ui_g_Self_aim_NewText->str_length = 8;
    strcpy(ui_g_Self_aim_NewText->string, "Self_Aim");


    ui_proc_string_frame(&ui_g_Self_aim_1);
    SEND_MESSAGE((uint8_t *) &ui_g_Self_aim_1, sizeof(ui_g_Self_aim_1));
}

void _ui_update_g_Self_aim_1() {
    ui_g_Self_aim_1.option.operate_type = 2;

    ui_proc_string_frame(&ui_g_Self_aim_1);
    SEND_MESSAGE((uint8_t *) &ui_g_Self_aim_1, sizeof(ui_g_Self_aim_1));
}

void _ui_remove_g_Self_aim_1() {
    ui_g_Self_aim_1.option.operate_type = 3;

    ui_proc_string_frame(&ui_g_Self_aim_1);
    SEND_MESSAGE((uint8_t *) &ui_g_Self_aim_1, sizeof(ui_g_Self_aim_1));
}

void ui_init_g_Self_aim() {
    _ui_init_g_Self_aim_0();
    _ui_init_g_Self_aim_1();
}

void ui_update_g_Self_aim() {
    _ui_update_g_Self_aim_0();
    _ui_update_g_Self_aim_1();
}

void ui_remove_g_Self_aim() {
    _ui_remove_g_Self_aim_0();
    _ui_remove_g_Self_aim_1();
}

ui_2_frame_t ui_g_Shoot_status_0;

ui_interface_number_t *ui_g_Shoot_status_Trigger_RPM = (ui_interface_number_t*)&(ui_g_Shoot_status_0.data[0]);
ui_interface_round_t *ui_g_Shoot_status_Friction_status = (ui_interface_round_t*)&(ui_g_Shoot_status_0.data[1]);

void _ui_init_g_Shoot_status_0() {
    for (int i = 0; i < 2; i++) {
        ui_g_Shoot_status_0.data[i].figure_name[0] = 0;
        ui_g_Shoot_status_0.data[i].figure_name[1] = 1;
        ui_g_Shoot_status_0.data[i].figure_name[2] = i + 0;
        ui_g_Shoot_status_0.data[i].operate_type = 1;
    }
    for (int i = 2; i < 2; i++) {
        ui_g_Shoot_status_0.data[i].operate_type = 0;
    }

    ui_g_Shoot_status_Trigger_RPM->figure_type = 6;
    ui_g_Shoot_status_Trigger_RPM->operate_type = 1;
    ui_g_Shoot_status_Trigger_RPM->layer = 0;
    ui_g_Shoot_status_Trigger_RPM->color = 0;
    ui_g_Shoot_status_Trigger_RPM->start_x = 399;
    ui_g_Shoot_status_Trigger_RPM->start_y = 836;
    ui_g_Shoot_status_Trigger_RPM->width = 2;
    ui_g_Shoot_status_Trigger_RPM->font_size = 20;
    ui_g_Shoot_status_Trigger_RPM->number = 12345;

    ui_g_Shoot_status_Friction_status->figure_type = 2;
    ui_g_Shoot_status_Friction_status->operate_type = 1;
    ui_g_Shoot_status_Friction_status->layer = 0;
    ui_g_Shoot_status_Friction_status->color = 7;
    ui_g_Shoot_status_Friction_status->start_x = 424;
    ui_g_Shoot_status_Friction_status->start_y = 751;
    ui_g_Shoot_status_Friction_status->width = 10;
    ui_g_Shoot_status_Friction_status->r = 18;


    ui_proc_2_frame(&ui_g_Shoot_status_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Shoot_status_0, sizeof(ui_g_Shoot_status_0));
}

void _ui_update_g_Shoot_status_0() {
    for (int i = 0; i < 2; i++) {
        ui_g_Shoot_status_0.data[i].operate_type = 2;
    }

    ui_proc_2_frame(&ui_g_Shoot_status_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Shoot_status_0, sizeof(ui_g_Shoot_status_0));
}

void _ui_remove_g_Shoot_status_0() {
    for (int i = 0; i < 2; i++) {
        ui_g_Shoot_status_0.data[i].operate_type = 3;
    }

    ui_proc_2_frame(&ui_g_Shoot_status_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Shoot_status_0, sizeof(ui_g_Shoot_status_0));
}

ui_string_frame_t ui_g_Shoot_status_1;
ui_interface_string_t* ui_g_Shoot_status_Friction = &(ui_g_Shoot_status_1.option);

void _ui_init_g_Shoot_status_1() {
    ui_g_Shoot_status_1.option.figure_name[0] = 0;
    ui_g_Shoot_status_1.option.figure_name[1] = 1;
    ui_g_Shoot_status_1.option.figure_name[2] = 2;
    ui_g_Shoot_status_1.option.operate_type = 1;

    ui_g_Shoot_status_Friction->figure_type = 7;
    ui_g_Shoot_status_Friction->operate_type = 1;
    ui_g_Shoot_status_Friction->layer = 0;
    ui_g_Shoot_status_Friction->color = 5;
    ui_g_Shoot_status_Friction->start_x = 116;
    ui_g_Shoot_status_Friction->start_y = 774;
    ui_g_Shoot_status_Friction->width = 3;
    ui_g_Shoot_status_Friction->font_size = 30;
    ui_g_Shoot_status_Friction->str_length = 8;
    strcpy(ui_g_Shoot_status_Friction->string, "Friction");


    ui_proc_string_frame(&ui_g_Shoot_status_1);
    SEND_MESSAGE((uint8_t *) &ui_g_Shoot_status_1, sizeof(ui_g_Shoot_status_1));
}

void _ui_update_g_Shoot_status_1() {
    ui_g_Shoot_status_1.option.operate_type = 2;

    ui_proc_string_frame(&ui_g_Shoot_status_1);
    SEND_MESSAGE((uint8_t *) &ui_g_Shoot_status_1, sizeof(ui_g_Shoot_status_1));
}

void _ui_remove_g_Shoot_status_1() {
    ui_g_Shoot_status_1.option.operate_type = 3;

    ui_proc_string_frame(&ui_g_Shoot_status_1);
    SEND_MESSAGE((uint8_t *) &ui_g_Shoot_status_1, sizeof(ui_g_Shoot_status_1));
}
ui_string_frame_t ui_g_Shoot_status_2;
ui_interface_string_t* ui_g_Shoot_status_Trigger = &(ui_g_Shoot_status_2.option);

void _ui_init_g_Shoot_status_2() {
    ui_g_Shoot_status_2.option.figure_name[0] = 0;
    ui_g_Shoot_status_2.option.figure_name[1] = 1;
    ui_g_Shoot_status_2.option.figure_name[2] = 3;
    ui_g_Shoot_status_2.option.operate_type = 1;

    ui_g_Shoot_status_Trigger->figure_type = 7;
    ui_g_Shoot_status_Trigger->operate_type = 1;
    ui_g_Shoot_status_Trigger->layer = 0;
    ui_g_Shoot_status_Trigger->color = 0;
    ui_g_Shoot_status_Trigger->start_x = 123;
    ui_g_Shoot_status_Trigger->start_y = 836;
    ui_g_Shoot_status_Trigger->width = 3;
    ui_g_Shoot_status_Trigger->font_size = 30;
    ui_g_Shoot_status_Trigger->str_length = 7;
    strcpy(ui_g_Shoot_status_Trigger->string, "Trigger");


    ui_proc_string_frame(&ui_g_Shoot_status_2);
    SEND_MESSAGE((uint8_t *) &ui_g_Shoot_status_2, sizeof(ui_g_Shoot_status_2));
}

void _ui_update_g_Shoot_status_2() {
    ui_g_Shoot_status_2.option.operate_type = 2;

    ui_proc_string_frame(&ui_g_Shoot_status_2);
    SEND_MESSAGE((uint8_t *) &ui_g_Shoot_status_2, sizeof(ui_g_Shoot_status_2));
}

void _ui_remove_g_Shoot_status_2() {
    ui_g_Shoot_status_2.option.operate_type = 3;

    ui_proc_string_frame(&ui_g_Shoot_status_2);
    SEND_MESSAGE((uint8_t *) &ui_g_Shoot_status_2, sizeof(ui_g_Shoot_status_2));
}

void ui_init_g_Shoot_status() {
    _ui_init_g_Shoot_status_0();
    _ui_init_g_Shoot_status_1();
    _ui_init_g_Shoot_status_2();
}

void ui_update_g_Shoot_status() {
    _ui_update_g_Shoot_status_0();
    _ui_update_g_Shoot_status_1();
    _ui_update_g_Shoot_status_2();
}

void ui_remove_g_Shoot_status() {
    _ui_remove_g_Shoot_status_0();
    _ui_remove_g_Shoot_status_1();
    _ui_remove_g_Shoot_status_2();
}

ui_5_frame_t ui_g_Static_act_0;

ui_interface_line_t *ui_g_Static_act_y = (ui_interface_line_t*)&(ui_g_Static_act_0.data[0]);
ui_interface_line_t *ui_g_Static_act_x = (ui_interface_line_t*)&(ui_g_Static_act_0.data[1]);
ui_interface_rect_t *ui_g_Static_act_AIM_Rect = (ui_interface_rect_t*)&(ui_g_Static_act_0.data[2]);

void _ui_init_g_Static_act_0() {
    for (int i = 0; i < 3; i++) {
        ui_g_Static_act_0.data[i].figure_name[0] = 0;
        ui_g_Static_act_0.data[i].figure_name[1] = 2;
        ui_g_Static_act_0.data[i].figure_name[2] = i + 0;
        ui_g_Static_act_0.data[i].operate_type = 1;
    }
    for (int i = 3; i < 5; i++) {
        ui_g_Static_act_0.data[i].operate_type = 0;
    }

    ui_g_Static_act_y->figure_type = 0;
    ui_g_Static_act_y->operate_type = 1;
    ui_g_Static_act_y->layer = 0;
    ui_g_Static_act_y->color = 2;
    ui_g_Static_act_y->start_x = 940;
    ui_g_Static_act_y->start_y = 566;
    ui_g_Static_act_y->width = 2;
    ui_g_Static_act_y->end_x = 1021;
    ui_g_Static_act_y->end_y = 566;

    ui_g_Static_act_x->figure_type = 0;
    ui_g_Static_act_x->operate_type = 1;
    ui_g_Static_act_x->layer = 0;
    ui_g_Static_act_x->color = 2;
    ui_g_Static_act_x->start_x = 980;
    ui_g_Static_act_x->start_y = 400;
    ui_g_Static_act_x->width = 3;
    ui_g_Static_act_x->end_x = 980;
    ui_g_Static_act_x->end_y = 597;

    ui_g_Static_act_AIM_Rect->figure_type = 1;
    ui_g_Static_act_AIM_Rect->operate_type = 1;
    ui_g_Static_act_AIM_Rect->layer = 0;
    ui_g_Static_act_AIM_Rect->color = 0;
    ui_g_Static_act_AIM_Rect->start_x = 800;
    ui_g_Static_act_AIM_Rect->start_y = 378;
    ui_g_Static_act_AIM_Rect->width = 3;
    ui_g_Static_act_AIM_Rect->end_x = 1128;
    ui_g_Static_act_AIM_Rect->end_y = 706;


    ui_proc_5_frame(&ui_g_Static_act_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Static_act_0, sizeof(ui_g_Static_act_0));
}

void _ui_update_g_Static_act_0() {
    for (int i = 0; i < 3; i++) {
        ui_g_Static_act_0.data[i].operate_type = 2;
    }

    ui_proc_5_frame(&ui_g_Static_act_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Static_act_0, sizeof(ui_g_Static_act_0));
}

void _ui_remove_g_Static_act_0() {
    for (int i = 0; i < 3; i++) {
        ui_g_Static_act_0.data[i].operate_type = 3;
    }

    ui_proc_5_frame(&ui_g_Static_act_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Static_act_0, sizeof(ui_g_Static_act_0));
}


void ui_init_g_Static_act() {
    _ui_init_g_Static_act_0();
}

void ui_update_g_Static_act() {
    _ui_update_g_Static_act_0();
}

void ui_remove_g_Static_act() {
    _ui_remove_g_Static_act_0();
}

