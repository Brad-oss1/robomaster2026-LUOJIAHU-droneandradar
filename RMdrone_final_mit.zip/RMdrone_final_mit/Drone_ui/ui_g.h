//
// Created by RM UI Designer
// Static Edition
//

#ifndef UI_g_H
#define UI_g_H

#include "ui_interface.h"

extern ui_interface_round_t *ui_g_Self_aim_Self_aim_Flag;
extern ui_interface_string_t *ui_g_Self_aim_NewText;

void ui_init_g_Self_aim();
void ui_update_g_Self_aim();
void ui_remove_g_Self_aim();

extern ui_interface_number_t *ui_g_Shoot_status_Trigger_RPM;
extern ui_interface_round_t *ui_g_Shoot_status_Friction_status;
extern ui_interface_string_t *ui_g_Shoot_status_Friction;
extern ui_interface_string_t *ui_g_Shoot_status_Trigger;

void ui_init_g_Shoot_status();
void ui_update_g_Shoot_status();
void ui_remove_g_Shoot_status();

extern ui_interface_line_t *ui_g_Static_act_y;
extern ui_interface_line_t *ui_g_Static_act_x;
extern ui_interface_rect_t *ui_g_Static_act_AIM_Rect;

void ui_init_g_Static_act();
void ui_update_g_Static_act();
void ui_remove_g_Static_act();


#endif // UI_g_H
