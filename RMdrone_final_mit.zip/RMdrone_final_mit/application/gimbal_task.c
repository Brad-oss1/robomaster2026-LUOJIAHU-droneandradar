/**
  ****************************(C) COPYRIGHT 2019 DJI****************************
  * @file       gimbal_task.c/h
  * @brief      gimbal control task, because use the euler angle calculated by
  *             gyro sensor, range (-pi,pi), angle set-point must be in this 
  *             range.gimbal has two control mode, gyro mode and enconde mode
  *             gyro mode: use euler angle to control, encond mode: use enconde
  *             angle to control. and has some special mode:cali mode, motionless
  *             mode.
  *             �����̨��������������̨ʹ�������ǽ�����ĽǶȣ��䷶Χ�ڣ�-pi,pi��
  *             �ʶ�����Ŀ��ǶȾ�Ϊ��Χ����������ԽǶȼ���ĺ�������̨��Ҫ��Ϊ2��
  *             ״̬�������ǿ���״̬�����ð��������ǽ������̬�ǽ��п��ƣ�����������
  *             ״̬��ͨ����������ı���ֵ���Ƶ�У׼�����⻹��У׼״̬��ֹͣ״̬�ȡ�
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-26-2018     RM              1. done
  *  V1.1.0     Nov-11-2019     RM              1. add some annotation
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2019 DJI****************************
  */

#include "gimbal_task.h"
#include "main.h"
#include "cmsis_os.h"
#include "arm_math.h"
#include "CAN_receive.h"
#include "user_lib.h"
#include "detect_task.h"
#include "remote_control.h"
#include "INS_task.h"
#include "pid.h"
#include "Self_aim.h"
#include "stm32f4xx_hal.h"
#include "usart.h"
#include "gimbal_behaviour.h"

/**
  * @brief          remote control dealline solve,because the value of rocker is not zero in middle place,
  * @param          input:the raw channel value 
  * @param          output: the processed channel value
  * @param          deadline
  */
#define rc_deadband_limit(input, output, dealine)        \
    {                                                    \
        if ((input) > (dealine) || (input) < -(dealine)) \
        {                                                \
            (output) = (input);                          \
        }                                                \
        else                                             \
        {                                                \
            (output) = 0;                                \
        }                                                \
    }	 
	
	
//motor enconde value format, range[0-8191]
#define ecd_format(ecd)         \
    {                           \
        if ((ecd) > ECD_RANGE)  \
            (ecd) -= ECD_RANGE; \
        else if ((ecd) < 0)     \
            (ecd) += ECD_RANGE; \
    }

//PID parameters value format
#define gimbal_total_pid_clear(gimbal_clear)                                                   \
    {                                                                                          \
        gimbal_PID_clear(&(gimbal_clear)->gimbal_yaw_motor.gimbal_motor_absolute_angle_pid);   \
        gimbal_PID_clear(&(gimbal_clear)->gimbal_yaw_motor.gimbal_motor_relative_angle_pid);   \
        PID_clear(&(gimbal_clear)->gimbal_yaw_motor.gimbal_motor_gyro_pid);                    \
    }

#if INCLUDE_uxTaskGetStackHighWaterMark
uint32_t gimbal_high_water;

#endif
float yaw_angle_limit_func(float input) 
{
    if (input >= 180) {
        return input - 360;
    } else if (input <= -180) {
        return input + 360;
    } else {
        return input;
    }
}	

#define WINDOW_SIZE 10
float yaw_buffer[WINDOW_SIZE];
int data_index = 0;

float sliding_average(float new_yaw) {
    yaw_buffer[data_index] = new_yaw;
    data_index = (data_index + 1) % WINDOW_SIZE;
    float sum = 0;
    for (int i = 0; i < WINDOW_SIZE; i++) sum += yaw_buffer[i];
    return sum / WINDOW_SIZE;
}

/**
  * @brief          "gimbal_control" valiable initialization, include pid initialization, remote control data point initialization, gimbal motors
  *                 data point initialization, and gyro sensor angle point initialization.
  * @param[out]     init: "gimbal_control" valiable point
  * @retval         none
  */
static void gimbal_init(gimbal_control_t *init);

void chassis_rc_to_control_vector(gimbal_control_t *gimbal_control_set,chassis_data_t *chassis_data);

/**
  * @brief          set gimbal control mode, mainly call 'gimbal_behaviour_mode_set' function
  * @param[out]     gimbal_set_mode: "gimbal_control" valiable point
  * @retval         none
  */
static void gimbal_set_mode(gimbal_control_t *set_mode);

/**
  * @brief          gimbal some measure data updata, such as motor enconde, euler angle, gyro
  * @param[out]     gimbal_feedback_update: "gimbal_control" valiable point
  * @retval         none
  */
static void gimbal_feedback_update(gimbal_control_t *feedback_update);

/**
  * @brief          calculate the relative angle between ecd and offset_ecd
  * @param[in]      ecd: motor now encode
  * @param[in]      offset_ecd: gimbal offset encode
  * @retval         relative angle, unit rad
**/
static fp32 motor_ecd_to_angle_change(uint16_t ecd, uint16_t offset_ecd);

/**
  * @brief          set gimbal control set-point, control set-point is set by "gimbal_behaviour_control_set".         
  * @param[out]     gimbal_set_control: "gimbal_control" valiable point
  * @retval         none
  */
static void gimbal_set_control(gimbal_control_t *set_control);

/**
  * @brief          control loop, according to control set-point, calculate motor current, 
  *                 motor current will be sent to motor
  * @param[out]     gimbal_control_loop: "gimbal_control" valiable point
  * @retval         none
  */
static void gimbal_control_loop(gimbal_control_t *control_loop);

/**
  * @brief          when gimbal mode change, some param should be changed, suan as  yaw_set should be new yaw
  * @param[out]     gimbal_mode_change: "gimbal_control" valiable point
  * @retval         none
  */
static void gimbal_mode_change_control_transit(gimbal_control_t *gimbal_mode_change);

/**
  * @brief          gimbal angle pid init, because angle is in range(-pi,pi),can't use PID in pid.c
  * @param[out]     pid: pid data pointer stucture
  * @param[in]      maxout: pid max out
  * @param[in]      intergral_limit: pid max iout
  * @param[in]      kp: pid kp
  * @param[in]      ki: pid ki
  * @param[in]      kd: pid kd
  * @retval         noneF
  */
static void gimbal_PID_init(gimbal_PID_t *pid, fp32 maxout, fp32 intergral_limit, fp32 kp, fp32 ki, fp32 kd);

/**
  * @brief          gimbal PID clear, clear pid.out, iout.
  * @param[out]     pid_clear: "gimbal_control" valiable point
  * @retval         none
  */

static void gimbal_PID_clear(gimbal_PID_t *pid_clear);

/**
  * @brief          gimbal angle pid calc, because angle is in range(-pi,pi),can't use PID in pid.c
  * @param[out]     pid: pid data pointer stucture
  * @param[in]      get: angle feeback
  * @param[in]      set: angle set-point
  * @param[in]      error_delta: rotation speed
  * @retval         pid out
  */
static fp32 gimbal_PID_calc(gimbal_PID_t *pid, fp32 get, fp32 set, fp32 error_delta);

/**
  * @brief          gimbal control mode :GIMBAL_MOTOR_ENCONDE, use the encode relative angle  to control. 
  * @param[out]     gimbal_motor: yaw motor or pitch motor
  * @retval         none
  */
  
static void gimbal_relative_angle_limit(gimbal_motor_t *gimbal_motor, fp32 add);

/**
  * @brief          limit angle set in GIMBAL_MOTOR_GYRO mode, avoid exceeding the max angle
  * @param[out]     gimbal_motor: yaw motor or pitch motor
  * @retval         none
  */
static void gimbal_absolute_angle_limit(gimbal_motor_t *gimbal_motor, fp32 add);
/**
  * @brief          gimbal control mode :GIMBAL_MOTOR_ENCONDE, use the encode relative angle  to control. 
  * @param[out]     gimbal_motor: yaw motor or pitch motor
  * @retval         none
  */
static void gimbal_motor_relative_angle_control(gimbal_motor_t *gimbal_motor);

/**
  * @brief          gimbal control mode :GIMBAL_MOTOR_GYRO, use euler angle calculated by gyro sensor to control. 
  * @param[out]     gimbal_motor: yaw motor or pitch motor
  * @retval         none
  */
static void gimbal_motor_absolute_angle_control(gimbal_motor_t *gimbal_motor);
/**
  * @brief          gimbal control mode :GIMBAL_MOTOR_RAW, current  is sent to CAN bus. 
  * @param[out]     gimbal_motor: yaw motor or pitch motor
  * @retval         none
  */	
static void disable_detect(gimbal_control_t *gimbal_disable_motor);
static void enable_detect(gimbal_control_t *gimbal_enable_motor);
static void gimbal_motor_raw_angle_control(gimbal_motor_t *gimbal_motor);
static void gimbal_dm_motor_absolute_angle_control(gimbal_motor_t *gimbal_motor);

void angle_limit(fp32* angle,fp32 min_angle,fp32 max_angle);
void angle_error_update(gimbal_control_t* gimbal);
#if GIMBAL_TEST_MODE
//j-scope to help pid adjust parameters
static void J_scope_gimbal_test(void);
#endif

//gimbal control data
gimbal_control_t gimbal_control;
uint8_t chassis_flag=0,aimflag=0,turnflag=0,disable_flag=0,enable_flag = 0;
 uint32_t disable_time,enable_time;

//chassis contol data(no use in drone PROJECT)
chassis_data_t chassis_data;

//InputData *Self_aim_data;
//const motor_measure_t *a;
//first_order_filter_type_t chassis_self_aim_yaw;
//const static fp32 chassis_self_aim_yaw_filter[1] = {CHASSIS_ACCEL_Y_NUM};

//filter for self_aim
LowPassFilter_t Self_aim_filter_yaw,Self_aim_filter_pitch;
uint8_t flag1=0;

//motor current 
static int16_t shoot_can_set_current = 0;
static fp32 yaw_can_set_torque = 0.0f, pitch_can_set_torque = 0.0f;
fp32 pitch_angle_set,pitch_angle_error;//this error is for wrongly installed 
fp32 angle_set;
/**
  * @brief          gimbal task, osDelay GIMBAL_CONTROL_TIME (1ms) 
  * @param[in]      pvParameters: null
  * @retval         none
  */
/**
  * @brief          ��̨���񣬼�� GIMBAL_CONTROL_TIME 1ms
  * @param[in]      pvParameters: ��
  * @retval         none
  */

void gimbal_task(void const *pvParameters)
{
    //wait a time
    vTaskDelay(GIMBAL_TASK_INIT_TIME);
    //gimbal init
    gimbal_init(&gimbal_control);
    //shoot init
    shoot_Init();
	gimbal_control.gimbal_yaw_motor.max_relative_angle = GIMBAL_YAW_MAX_RELATIVE_ANGLE;
	gimbal_control.gimbal_yaw_motor.min_relative_angle = GIMBAL_YAW_MIN_RELATIVE_ANGLE;
	
	
    //wait for all motor online
//    while (toe_is_error(YAW_GIMBAL_MOTOR_TOE) || toe_is_error(PITCH_GIMBAL_MOTOR_TOE))
//    {
//        vTaskDelay(GIMBAL_CONTROL_TIME);
//        gimbal_feedback_update(&gimbal_control);             //��̨���ݷ���
//    }
	
    while (1)
    {
//		chassis_rc_to_control_vector(&gimbal_control,&chassis_data);//���õ��̿�����
		enable_detect(&gimbal_control);
		disable_detect(&gimbal_control);
        gimbal_set_mode(&gimbal_control);                    //������̨����ģʽ s0�����¸˸ı�
        gimbal_mode_change_control_transit(&gimbal_control); //����ģʽ�л� �������ݹ���
        gimbal_feedback_update(&gimbal_control);             //��̨���ݷ���
        gimbal_set_control(&gimbal_control);                 //����set_mode�����ֵ���ö�Ӧ������
		gimbal_control_loop(&gimbal_control);  			  //��̨����PID����
		gimbal_control.shoot = shoot_control_loop();
		shoot_can_set_current = gimbal_control.shoot->trigger_given_current;
		
		if(gimbal_control.gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_ENCONDE)
		{
			yaw_can_set_torque = gimbal_control.gimbal_yaw_motor.torque_set * 0.59f;
		}
		else if(gimbal_control.gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_GYRO )
		{
			yaw_can_set_torque = -gimbal_control.gimbal_yaw_motor.torque_set;
		}
		
		if(gimbal_control.gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_ENCONDE)
		{
			pitch_can_set_torque = gimbal_control.gimbal_pitch_motor.torque_set;
		}
		else if(gimbal_control.gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_GYRO)
		{
			pitch_can_set_torque = gimbal_control.gimbal_pitch_motor.torque_set ;
		}

		//���͵���end
		CAN_cmd_gimbal(0,0,shoot_can_set_current,0);
		MIT_CtrlMotor(0,0,0,0.3,yaw_can_set_torque,CAN_YAW_MOTOR_ID);
		MIT_CtrlMotor(0,0,0,0.3,pitch_can_set_torque,CAN_PIT_MOTOR_ID);
		CAN_cmd_chassis(gimbal_control.shoot->friction_left_given_current,gimbal_control.shoot->friction_right_given_current,0,0);
//		speed_ctrl(pitch_can_set_omega,CAN_PIT_MOTOR_ID);
//		if(gimbal_control.gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_ENCONDE)
//		{
//			pitch_angle_set = -gimbal_control.gimbal_pitch_motor.relative_angle_set;
//		}
//		else if(gimbal_control.gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_GYRO)
//		{
//			pitch_angle_set = (gimbal_control.gimbal_pitch_motor.absolute_angle_set - gimbal_control.gimbal_pitch_motor.fixed_error)/RAD_TO_DEGREE;
//		}
//		angle_limit(&pitch_angle_set,(-50/RAD_TO_DEGREE),(50/RAD_TO_DEGREE));//-30to+50
//		MIT_CtrlMotor(0,0.1,0,0.2,0);	
//		pos_sped_ctrl(pitch_angle_set,500);
//gimbal_control.gimbal_pitch_motor.relative_angle_set
				//	CAN_cmd_gimbal(0,gimbal_control.gimbal_pitch_motor.given_current,0,0);
		//CAN_cmd_gimbal(0,0,0,0);
		vTaskDelay(GIMBAL_CONTROL_TIME);


    }
}
/**
  * @brief          return yaw motor data point
  * @param[in]      none
  * @retval         yaw motor data point
  */
/**
  * @brief          ����yaw �������ָ��
  * @param[in]      none
  * @retval         yaw���ָ��
  */
const gimbal_motor_t *get_yaw_motor_point(void)
{
    return &gimbal_control.gimbal_yaw_motor;
}

/**
  * @brief          return pitch motor data point
  * @param[in]      none
  * @retval         pitch motor data point
  */
/**
  * @brief          ����pitch �������ָ��
  * @param[in]      none
  * @retval         pitch
  */
const gimbal_motor_t *get_pitch_motor_point(void)
{
    return &gimbal_control.gimbal_pitch_motor;
}

/**
  * @brief          "gimbal_control" valiable initialization, include pid initialization, remote control data point initialization, gimbal motors
  *                 data point initialization, and gyro sensor angle point initialization.
  * @param[out]     init: "gimbal_control" valiable point
  * @retval         none
  */
/**
  * @brief          ��ʼ��"gimbal_control"����������pid��ʼ���� ң����ָ���ʼ������̨���ָ���ʼ���������ǽǶ�ָ���ʼ��
  * @param[out]     init:"gimbal_control"����ָ��.
  * @retval         none
  */
static void gimbal_init(gimbal_control_t *init)
{
	//pid data
    static const fp32 Pitch_speed_pid[3] = {PITCH_SPEED_PID_KP, PITCH_SPEED_PID_KI, PITCH_SPEED_PID_KD};
    static const fp32 Yaw_speed_pid[3] = {YAW_SPEED_PID_KP, YAW_SPEED_PID_KI, YAW_SPEED_PID_KD};
//    static const fp32 Pitch_speed_pid[3] = {PITCH_GYRO_ABSOLUTE_PID_KP, PITCH_GYRO_ABSOLUTE_PID_KI, PITCH_GYRO_ABSOLUTE_PID_KD};
   
	//max/min angle init
	init->gimbal_pitch_motor.max_relative_angle = GIMBAL_PITCH_MAX_RELATIVE_ANGLE;
	init->gimbal_pitch_motor.min_relative_angle = GIMBAL_PITCH_MIN_RELATIVE_ANGLE;
	
	 //get yaw&pitch motor data
    init->gimbal_yaw_motor.dm_gimbal_motor_measure = get_yaw_gimbal_motor_measure_point();
    init->gimbal_pitch_motor.dm_gimbal_motor_measure = get_pitch_gimbal_motor_measure_point();
    //get gyro data
    init->gimbal_INT_angle_point = get_INS_angle_point();
    init->gimbal_INT_gyro_point = get_gyro_data_point();
    //get rc data
    init->gimbal_rc_ctrl = get_remote_control_point();
    //init motor_mode
    init->gimbal_yaw_motor.gimbal_motor_mode = init->gimbal_yaw_motor.last_gimbal_motor_mode = GIMBAL_MOTOR_OFF;
    init->gimbal_pitch_motor.gimbal_motor_mode = init->gimbal_pitch_motor.last_gimbal_motor_mode = GIMBAL_MOTOR_OFF;
    //yaw motor angle loop pid init
    gimbal_PID_init(&init->gimbal_yaw_motor.gimbal_motor_absolute_angle_pid, YAW_GYRO_ABSOLUTE_PID_MAX_OUT, YAW_GYRO_ABSOLUTE_PID_MAX_IOUT, YAW_GYRO_ABSOLUTE_PID_KP, YAW_GYRO_ABSOLUTE_PID_KI, YAW_GYRO_ABSOLUTE_PID_KD);
    gimbal_PID_init(&init->gimbal_yaw_motor.gimbal_motor_relative_angle_pid, YAW_ENCODE_RELATIVE_PID_MAX_OUT, YAW_ENCODE_RELATIVE_PID_MAX_IOUT, YAW_ENCODE_RELATIVE_PID_KP, YAW_ENCODE_RELATIVE_PID_KI, YAW_ENCODE_RELATIVE_PID_KD);
	//pitch motor pid init
    gimbal_PID_init(&init->gimbal_pitch_motor.gimbal_motor_absolute_angle_pid, PITCH_GYRO_ABSOLUTE_PID_MAX_OUT, PITCH_GYRO_ABSOLUTE_PID_MAX_IOUT, PITCH_GYRO_ABSOLUTE_PID_KP, PITCH_GYRO_ABSOLUTE_PID_KI, PITCH_GYRO_ABSOLUTE_PID_KD);
	gimbal_PID_init(&init->gimbal_pitch_motor.gimbal_motor_relative_angle_pid,PITCH_ENCODE_RELATIVE_PID_MAX_OUT,PITCH_ENCODE_RELATIVE_PID_MAX_IOUT,PITCH_ENCODE_RELATIVE_PID_KP,PITCH_ENCODE_RELATIVE_PID_KI,PITCH_ENCODE_RELATIVE_PID_KD);
	//yaw motor speed loop pid init
	  PID_init(&init->gimbal_yaw_motor.gimbal_motor_gyro_pid, PID_POSITION, Yaw_speed_pid, YAW_SPEED_PID_MAX_OUT, YAW_SPEED_PID_MAX_IOUT);
    PID_init(&init->gimbal_pitch_motor.gimbal_motor_gyro_pid,PID_POSITION,Pitch_speed_pid,PITCH_SPEED_PID_MAX_OUT,PITCH_SPEED_PID_MAX_IOUT);
    
	//self_aim angle filter
	  LowPassFilter_Init(&Self_aim_filter_yaw,0.00078,10);
	  LowPassFilter_Init(&Self_aim_filter_pitch,0.00078,10);

    //clear data in PID
    gimbal_total_pid_clear(init);
	init->gimbal_pitch_motor.offset_pos = -2.355f;

    gimbal_feedback_update(init);
    init->gimbal_yaw_motor.absolute_angle_set = init->gimbal_yaw_motor.absolute_angle;
    init->gimbal_yaw_motor.relative_angle_set = init->gimbal_yaw_motor.relative_angle;
    init->gimbal_yaw_motor.motor_gyro_set = init->gimbal_yaw_motor.motor_gyro;

    init->gimbal_pitch_motor.absolute_angle_set = init->gimbal_pitch_motor.absolute_angle;
    init->gimbal_pitch_motor.relative_angle_set = init->gimbal_pitch_motor.relative_angle;
   init->gimbal_pitch_motor.motor_gyro_set = init->gimbal_pitch_motor.motor_gyro;
	
	init_end =1;
	
	
}

/**
  * @brief          set gimbal control mode, mainly call 'gimbal_behaviour_mode_set' function
  * @param[out]     gimbal_set_mode: "gimbal_control" valiable point
  * @retval         none
  */
/**
  * @brief          ������̨����ģʽ����Ҫ��'gimbal_behaviour_mode_set'�����иı�
  * @param[out]     gimbal_set_mode:"gimbal_control"����ָ��.
  * @retval         none
  */
static void gimbal_set_mode(gimbal_control_t *set_mode)
{
   if (set_mode == NULL)
    {
        return;
    }
    gimbal_behaviour_mode_set(set_mode);
}
/**
  * @brief          gimbal some measure data updata, such as motor enconde, euler angle, gyro
  * @param[out]     gimbal_feedback_update: "gimbal_control" valiable point
  * @retval         none
  */
/**
  * @brief          ���̲������ݸ��£���������ٶȣ�ŷ���Ƕȣ��������ٶ�
  * @param[out]     gimbal_feedback_update:"gimbal_control"����ָ��.
  * @retval         none
  */
static void gimbal_feedback_update(gimbal_control_t *feedback_update)
{
    if (feedback_update == NULL)
    {
        return;
    }
	float last_gyro;
    //��̨���ݸ���
	//pitch
	feedback_update->gimbal_pitch_motor.relative_angle = (feedback_update->gimbal_pitch_motor.dm_gimbal_motor_measure->pos - feedback_update->gimbal_pitch_motor.offset_pos);                      
	feedback_update->gimbal_pitch_motor.absolute_angle = *(feedback_update->gimbal_INT_angle_point + INS_PITCH_ADDRESS_OFFSET);
	//angular speed
    feedback_update->gimbal_pitch_motor.motor_gyro = *(feedback_update->gimbal_INT_gyro_point + INS_GYRO_Y_ADDRESS_OFFSET);
	//yaw
	feedback_update->gimbal_yaw_motor.absolute_angle = *(feedback_update->gimbal_INT_angle_point + INS_YAW_ADDRESS_OFFSET);
	
	feedback_update->gimbal_yaw_motor.relative_angle = feedback_update->gimbal_yaw_motor.dm_gimbal_motor_measure->pos;
	feedback_update->gimbal_yaw_motor.motor_gyro = arm_cos_f32(feedback_update->gimbal_pitch_motor.relative_angle) * (*(feedback_update->gimbal_INT_gyro_point + INS_GYRO_Z_ADDRESS_OFFSET))
													-arm_sin_f32(feedback_update->gimbal_pitch_motor.relative_angle) * (*(feedback_update->gimbal_INT_gyro_point + INS_GYRO_X_ADDRESS_OFFSET));
//	feedback_update->last_press_l=feedback_update->press_l;	
//	feedback_update->press_l=feedback_update->gimbal_rc_ctrl->mouse.press_l;
//	feedback_update->lastkeyboard=feedback_update->keyboard;
//	feedback_update->keyboard=feedback_update->gimbal_rc_ctrl->key.v;
//	feedback_update->gimbal_pitch_motor.last_self_aim_pitch_angle=feedback_update->gimbal_pitch_motor.self_aim_pitch_angle;
//	feedback_update->gimbal_pitch_motor.self_aim_pitch_angle=Self_aim_data->shoot_pitch/3.14*180;
//	feedback_update->gimbal_yaw_motor.last_self_aim_yaw_angle=feedback_update->gimbal_yaw_motor.self_aim_yaw_angle;
//	feedback_update->gimbal_yaw_motor.self_aim_yaw_angle=sliding_average(Self_aim_data->shoot_yaw/3.14*180);
//	feedback_update->gimbal_yaw_motor.self_aim_yaw_angle=Self_aim_data->shoot_yaw/3.14*180;
	
}

/**
  * @brief          calculate the relative angle between ecd and offset_ecd
  * @param[in]      ecd: motor now encode
  * @param[in]      offset_ecd: gimbal offset encode
  * @retval         relative angle, unit rad
  */
/**
  * @brief          ����ecd��offset_ecd֮�����ԽǶ�
  * @param[in]      ecd: �����ǰ����
  * @param[in]      offset_ecd: �����ֵ����
  * @retval         ��ԽǶȣ���λrad
  */
static fp32 motor_ecd_to_angle_change(uint16_t ecd, uint16_t offset_ecd)
{
    int32_t relative_ecd = ecd - offset_ecd;
    if (relative_ecd > HALF_ECD_RANGE)
    {
        relative_ecd -= ECD_RANGE;
    }
    else if (relative_ecd < -HALF_ECD_RANGE)
    {
        relative_ecd += ECD_RANGE;
    }

    return relative_ecd * MOTOR_ECD_TO_RAD;
}

/**
  * @brief          when gimbal mode change, some param should be changed, suan as  yaw_set should be new yaw
  * @param[out]     gimbal_mode_change: "gimbal_control" valiable point
  * @retval         none
  */
/**
  * @brief          ��̨ģʽ�ı䣬��Щ������Ҫ�ı䣬�������yaw�Ƕ��趨ֵӦ�ñ�ɵ�ǰyaw�Ƕ�
  * @param[out]     gimbal_mode_change:"gimbal_control"����ָ��.
  * @retval         none
  */
static void gimbal_mode_change_control_transit(gimbal_control_t *gimbal_mode_change)
{
    if (gimbal_mode_change == NULL)
    {
        return;
    }
    //yaw���״̬���л���������
    if (gimbal_mode_change->gimbal_yaw_motor.last_gimbal_motor_mode != GIMBAL_MOTOR_OFF && gimbal_mode_change->gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_OFF)
    {
        gimbal_mode_change->gimbal_yaw_motor.raw_cmd_current = gimbal_mode_change->gimbal_yaw_motor.motor_gyro_set = 0.0f;
    }
    else if (gimbal_mode_change->gimbal_yaw_motor.last_gimbal_motor_mode != GIMBAL_MOTOR_GYRO && gimbal_mode_change->gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_GYRO)
    {
        gimbal_mode_change->gimbal_yaw_motor.absolute_angle_set = gimbal_mode_change->gimbal_yaw_motor.absolute_angle;
    }
    else if (gimbal_mode_change->gimbal_yaw_motor.last_gimbal_motor_mode != GIMBAL_MOTOR_ENCONDE && gimbal_mode_change->gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_ENCONDE)
    {
        gimbal_mode_change->gimbal_yaw_motor.relative_angle_set = gimbal_mode_change->gimbal_yaw_motor.relative_angle;
    }
	
    gimbal_mode_change->gimbal_yaw_motor.last_gimbal_motor_mode = gimbal_mode_change->gimbal_yaw_motor.gimbal_motor_mode;

    //pitch���״̬���л���������
    if (gimbal_mode_change->gimbal_pitch_motor.last_gimbal_motor_mode != GIMBAL_MOTOR_OFF && gimbal_mode_change->gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_OFF)
    {
        gimbal_mode_change->gimbal_pitch_motor.raw_cmd_current = gimbal_mode_change->gimbal_pitch_motor.motor_gyro_set = 0.0f;
    }
    else if (gimbal_mode_change->gimbal_pitch_motor.last_gimbal_motor_mode != GIMBAL_MOTOR_GYRO && gimbal_mode_change->gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_GYRO)
    {
        gimbal_mode_change->gimbal_pitch_motor.absolute_angle_set = gimbal_mode_change->gimbal_pitch_motor.absolute_angle;
    }
    else if (gimbal_mode_change->gimbal_pitch_motor.last_gimbal_motor_mode != GIMBAL_MOTOR_ENCONDE && gimbal_mode_change->gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_ENCONDE)
    {
        gimbal_mode_change->gimbal_pitch_motor.relative_angle_set = gimbal_mode_change->gimbal_pitch_motor.relative_angle;
    }

    gimbal_mode_change->gimbal_pitch_motor.last_gimbal_motor_mode = gimbal_mode_change->gimbal_pitch_motor.gimbal_motor_mode;
}

/**
  * @brief          set gimbal control set-point, control set-point is set by "gimbal_behaviour_control_set".         
  * @param[out]     gimbal_set_control: "gimbal_control" valiable point
  * @retval         none
  */
/**
  * @brief          ������̨�����趨ֵ������ֵ��ͨ��gimbal_behaviour_control_set�������õ�
  * @param[out]     gimbal_set_control:"gimbal_control"����ָ��.
  * @retval         none
  */
static void gimbal_set_control(gimbal_control_t *set_control)
{
	  if (set_control == NULL)
    {
        return;
    }
	//�Ƕ�ƫ�� ��һ��Ϊ0
	fp32 add_yaw_angle = 0.0f;
    fp32 add_pitch_angle = 0.0f;
	
	static  int16_t pitch_channel = 0;
	rc_deadband_limit(set_control->gimbal_rc_ctrl->rc.ch[PITCH_CHANNEL], pitch_channel, RC_DEADBAND); 
	
	//core
	gimbal_behaviour_control_set(&add_yaw_angle, &add_pitch_angle, set_control);
	
//	if (set_control->gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_ENCONDE)
//    {
//        //encondeģʽ�£��������Ƕȿ���
//        gimbal_relative_angle_limit(&set_control->gimbal_yaw_motor, add_yaw_angle);
//		gimbal_relative_angle_limit(&set_control->gimbal_pitch_motor, add_pitch_angle);
//    }
		
	//yaw���ģʽ����
	 if (set_control->gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_OFF)
    {
        //rawģʽς£¬ֱ½ӷ¢ˍ¿ؖƖµ
        set_control->gimbal_yaw_motor.raw_cmd_current = add_yaw_angle;
    }
	else if (set_control->gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_GYRO)
    {
        //gyroģʽ�£������ǽǶȿ��� yaw0
        gimbal_absolute_angle_limit(&set_control->gimbal_yaw_motor, add_yaw_angle);
    }
    else if (set_control->gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_ENCONDE)
    {
        //encondeģʽ�£��������Ƕȿ���
        gimbal_relative_angle_limit(&set_control->gimbal_yaw_motor, add_yaw_angle);
    }

    //pitch���ģʽ����
	 if (set_control->gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_OFF)
    {
        //rawģʽς£¬ֱ½ӷ¢ˍ¿ؖƖµ
        set_control->gimbal_pitch_motor.raw_cmd_current = add_pitch_angle;
    }
	else if (set_control->gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_GYRO)
    {
        //gyroģʽ�£������ǽǶȿ��� pitch1
        gimbal_absolute_angle_limit(&set_control->gimbal_pitch_motor, add_pitch_angle);
    }
    else if (set_control->gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_ENCONDE)
    {
        //encondeģʽ�£��������Ƕȿ���
        gimbal_relative_angle_limit(&set_control->gimbal_pitch_motor, add_pitch_angle);
    }			
	

	
	
	//    if(set_control->gimbal_pitch_motor.gimbal_motor_mode==GIMBAL_MOTOR_GYRO&&aimflag==1)	
//	{
//        //set_control->gimbal_pitch_motor.absolute_angle_set-=pitch_channel*PITCH_RC_SEN+set_control->gimbal_rc_ctrl->mouse.y*PITCH_MOUSE_SEN;
//		//set_control->gimbal_pitch_motor.absolute_angle_set=set_control->gimbal_pitch_motor.self_aim_pitch_angle+1.5;
//		set_control->gimbal_pitch_motor.relative_angle_set-=pitch_channel*PITCH_RC_SEN+set_control->gimbal_rc_ctrl->mouse.y*PITCH_MOUSE_SEN*0.5;
//		if(set_control->gimbal_pitch_motor.relative_angle_set<-19)
//		{
//			set_control->gimbal_pitch_motor.relative_angle_set=-19;
//		}
//		else if(set_control->gimbal_pitch_motor.absolute_angle_set>29)
//		{
//			set_control->gimbal_pitch_motor.relative_angle_set=29;
//		}
//		else
//		{
//			set_control->gimbal_pitch_motor.absolute_angle_set=set_control->gimbal_pitch_motor.absolute_angle_set;
//		}
//	}
//	else if(set_control->gimbal_pitch_motor.gimbal_motor_mode==GIMBAL_MOTOR_ENCONDE&&aimflag==0)
//	{
//		set_control->gimbal_pitch_motor.absolute_angle_set-=pitch_channel*PITCH_RC_SEN+set_control->gimbal_rc_ctrl->mouse.y*PITCH_MOUSE_SEN;
//		if(set_control->gimbal_pitch_motor.absolute_angle_set<-19)
//		{
//			set_control->gimbal_pitch_motor.absolute_angle_set=-19;
//		}
//		else if(set_control->gimbal_pitch_motor.absolute_angle_set>29)
//		{
//			set_control->gimbal_pitch_motor.absolute_angle_set=29;
//		}
//		else
//		{
//			set_control->gimbal_pitch_motor.absolute_angle_set=set_control->gimbal_pitch_motor.absolute_angle_set;
//		}
//	}
	
}

/**
  * @brief          control loop, according to control set-point, calculate motor current, 
  *                 motor current will be sent to motor
  * @param[out]     gimbal_control_loop: "gimbal_control" valiable point
  * @retval         none
  */
/**
  * @brief          ����ѭ�������ݿ����趨ֵ������������ֵ�����п���
  * @param[out]     gimbal_control_loop:"gimbal_control"����ָ��.
  * @retval         none
  */
static void gimbal_control_loop(gimbal_control_t *control_loop)
{
	if (control_loop == NULL)
    {
        return;
    }
	
//    if(control_loop->gimbal_pitch_motor.gimbal_motor_mode==GIMBAL_MOTOR_OFF)
//	{

//	}
//	else if(control_loop->gimbal_pitch_motor.gimbal_motor_mode==GIMBAL_MOTOR_ENCONDE)
//	{
//		 gimbal_motor_relative_angle_control(&control_loop->gimbal_yaw_motor);
//		 gimbal_motor_relative_angle_control(&control_loop->gimbal_pitch_motor);
//	}
//	else if(control_loop->gimbal_pitch_motor.gimbal_motor_mode==GIMBAL_MOTOR_ENCONDE)
//	{
//		 gimbal_motor_absolute_angle_control(&control_loop->gimbal_yaw_motor);
//		 gimbal_motor_absolute_angle_control(&control_loop->gimbal_pitch_motor);
//	}
	 if (control_loop->gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_OFF)
    {
        gimbal_motor_raw_angle_control(&control_loop->gimbal_yaw_motor);
    }
	else if (control_loop->gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_GYRO)
    {
        gimbal_motor_absolute_angle_control(&control_loop->gimbal_yaw_motor);
    }
    else if (control_loop->gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_ENCONDE)
    {
        gimbal_motor_relative_angle_control(&control_loop->gimbal_yaw_motor);
    }

	if (control_loop->gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_OFF)
    {
        gimbal_motor_raw_angle_control(&control_loop->gimbal_pitch_motor);
    }
	else if (control_loop->gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_GYRO)
    {
        gimbal_motor_absolute_angle_control(&control_loop->gimbal_pitch_motor);
    }
    else if (control_loop->gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_ENCONDE)
    {
        gimbal_motor_relative_angle_control(&control_loop->gimbal_pitch_motor);
    }
}
/**
  * @brief          gimbal control mode :GIMBAL_MOTOR_RAW, current  is sent to CAN bus. 
  * @param[out]     gimbal_motor: yaw motor or pitch motor
  * @retval         none
  */
static void gimbal_motor_raw_angle_control(gimbal_motor_t *gimbal_motor)
{
    if (gimbal_motor == NULL)
    {
        return;
    }
//    gimbal_motor->current_set = gimbal_motor->raw_cmd_current;
//    gimbal_motor->given_current = (int16_t)(gimbal_motor->current_set);
}

/**
  * @brief          gimbal control mode :GIMBAL_MOTOR_GYRO, use euler angle calculated by gyro sensor to control. 
  * @param[out]     gimbal_motor: yaw motor or pitch motor
  * @retval         none
  */
/**
  * @brief          ��̨����ģʽ:GIMBAL_MOTOR_GYRO��ʹ�������Ǽ����ŷ���ǽ��п���
  * @param[out]     gimbal_motor:yaw�������pitch���
  * @retval         none
  */
static void gimbal_motor_absolute_angle_control(gimbal_motor_t *gimbal_motor)
{
    if (gimbal_motor == NULL)
    {
        return;
    }
	
		gimbal_motor->motor_gyro_set = gimbal_PID_calc(&gimbal_motor->gimbal_motor_absolute_angle_pid, gimbal_motor->absolute_angle, gimbal_motor->absolute_angle_set,gimbal_motor->motor_gyro);
		gimbal_motor->torque_set = PID_calc((&gimbal_motor->gimbal_motor_gyro_pid),( gimbal_motor->motor_gyro), (gimbal_motor->motor_gyro_set));

}


/**
  * @brief          gimbal control mode :GIMBAL_MOTOR_ENCONDE, use the encode relative angle  to control. 
  * @param[out]     gimbal_motor: yaw motor or pitch motor
  * @retval         none
  */
/**
  * @brief          ��̨����ģʽ:GIMBAL_MOTOR_ENCONDE��ʹ�ñ�����Խǽ��п���
  * @param[out]     gimbal_motor:yaw�������pitch���
  * @retval         none
  */
static void gimbal_motor_relative_angle_control(gimbal_motor_t *gimbal_motor)
{
    if (gimbal_motor == NULL)
    {
        return;
    }

    //�ǶȻ����ٶȻ�����pid����
    gimbal_motor->motor_gyro_set = gimbal_PID_calc((&gimbal_motor->gimbal_motor_relative_angle_pid), (gimbal_motor->relative_angle), (gimbal_motor->relative_angle_set), (gimbal_motor->dm_gimbal_motor_measure->vel));
	gimbal_motor->torque_set = PID_calc((&gimbal_motor->gimbal_motor_gyro_pid),( gimbal_motor->motor_gyro), (gimbal_motor->motor_gyro_set));

}
/**
  * @brief          "gimbal_control" valiable initialization, include pid initialization, remote control data point initialization, gimbal motors
  *                 data point initialization, and gyro sensor angle point initialization.
  * @param[out]     gimbal_init: "gimbal_control" valiable point
  * @retval         none
  */
static void gimbal_PID_init(gimbal_PID_t *pid, fp32 maxout, fp32 max_iout, fp32 kp, fp32 ki, fp32 kd)
{
    if (pid == NULL)
    {
        return;
    }
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;

    pid->err = 0.0f;
    pid->get = 0.0f;

    pid->max_iout = max_iout;
    pid->max_out = maxout;
}
/**
  * @brief          outer loop PIDcalc 
  * @param[errordelta] accept "motor_gyro" from inner loop 
  * @param[out]     be the set for inner pidcalc
  * @retval         none
  */
static fp32 gimbal_PID_calc(gimbal_PID_t *pid, fp32 get, fp32 set, fp32 error_delta)
{
    fp32 err;
    if (pid == NULL)
    {
        return 0.0f;
    }
    pid->get = get;
    pid->set = set;

    err = set - get;
    pid->err = err;
    pid->Pout = pid->kp * pid->err;
    pid->Iout += pid->ki * pid->err;
    pid->Dout = pid->kd * error_delta;
    abs_limit(pid->Iout, pid->max_iout);
    pid->out = pid->Pout + pid->Iout + pid->Dout; 
    abs_limit(pid->out, pid->max_out);
    return pid->out;
}

/**
  * @brief          gimbal PID clear, clear err,set,get,all types of OUT
  * @param[out]     gimbal_pid_clear: "gimbal_control" valiable point
  * @retval         none
  */
static void gimbal_PID_clear(gimbal_PID_t *gimbal_pid_clear)
{
    if (gimbal_pid_clear == NULL)
    {
        return;
    }
    gimbal_pid_clear->err = gimbal_pid_clear->set = gimbal_pid_clear->get = 0.0f;
    gimbal_pid_clear->out = gimbal_pid_clear->Pout = gimbal_pid_clear->Iout = gimbal_pid_clear->Dout = 0.0f;
}
//void chassis_rc_to_control_vector(gimbal_control_t *gimbal_control_set,chassis_data_t *chassis_data)
//{
//    int16_t vx_channel, vy_channel;
//    fp32 vx_set_channel, vy_set_channel;
//	fp32 angleset;
//	static int16_t yaw_channel = 0;
//	const static fp32 chassis_x_order_filter[1] = {CHASSIS_ACCEL_X_NUM};
//    const static fp32 chassis_y_order_filter[1] = {CHASSIS_ACCEL_Y_NUM};
//    //deadline, because some remote control need be calibrated,  the value of rocker is not zero in middle place,
//    //�������ƣ���Ϊң�������ܴ��ڲ��� ҡ�����м䣬��ֵ��Ϊ0
//    rc_deadband_limit(gimbal_control_set->gimbal_rc_ctrl->rc.ch[CHASSIS_X_CHANNEL], vx_channel, CHASSIS_RC_DEADLINE);
//    rc_deadband_limit(gimbal_control_set->gimbal_rc_ctrl->rc.ch[CHASSIS_Y_CHANNEL], vy_channel, CHASSIS_RC_DEADLINE);
//	rc_deadband_limit(gimbal_control_set->gimbal_rc_ctrl->rc.ch[YAW_CHANNEL], yaw_channel, RC_DEADBAND);
//    vx_set_channel = vx_channel * CHASSIS_VX_RC_SEN;
//    vy_set_channel = vy_channel * -CHASSIS_VY_RC_SEN;

//    //keyboard set speed set-point
//    //���̿���
//	if(gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_W)
//	{
//		vx_set_channel=1.5;
//	}
//	else if(gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_S)
//	{
//		vx_set_channel=-1.5;
//	}
//	else if(gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_A)
//	{
//		vy_set_channel=1.5;
//	}
//	else if(gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_D)
//	{
//		vy_set_channel=-1.5;
//	}
//	if(gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_W&&gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_SHIFT)
//	{
//		vx_set_channel=2;
//	}
//	else if(gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_S&&gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_SHIFT)
//	{
//		vx_set_channel=-2;
//	}
//	else if(gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_A&&gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_SHIFT)
//	{
//		vy_set_channel=2;
//	}
//	else if(gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_D&&gimbal_control_set->gimbal_rc_ctrl->key.v&KEY_PRESSED_OFFSET_SHIFT)
//	{
//		vy_set_channel=-2;
//	}
//	//
//	first_order_filter_init(&chassis_data->chassis_cmd_slow_set_vx, GIMBAL_CONTROL_TIME, chassis_x_order_filter);
//    first_order_filter_init(&chassis_data->chassis_cmd_slow_set_vy, GIMBAL_CONTROL_TIME, chassis_y_order_filter);
//    //first order low-pass replace ramp function, calculate chassis speed set-point to improve control performance
//    //һ�׵�ͨ�˲�����б����Ϊ�����ٶ�����
//    first_order_filter_cali(&chassis_data->chassis_cmd_slow_set_vx, vx_set_channel);
//    first_order_filter_cali(&chassis_data->chassis_cmd_slow_set_vy, vy_set_channel);
//	
//    //stop command, need not slow change, set zero derectly
//    //ֹͣ�źţ�����Ҫ�������٣�ֱ�Ӽ��ٵ���
//	
//    if (vx_set_channel < CHASSIS_RC_DEADLINE * CHASSIS_VX_RC_SEN && vx_set_channel > -CHASSIS_RC_DEADLINE * CHASSIS_VX_RC_SEN)
//    {
//        chassis_data->vx_set = 0.0f;
//    }

//    if (vy_set_channel < CHASSIS_RC_DEADLINE * CHASSIS_VY_RC_SEN && vy_set_channel > -CHASSIS_RC_DEADLINE * CHASSIS_VY_RC_SEN)
//    {
//        chassis_data->vy_set = 0.0f;
//    }
//	
//    chassis_data->vx_set = chassis_data->chassis_cmd_slow_set_vx.out;
//    chassis_data->vy_set = chassis_data->chassis_cmd_slow_set_vy.out;
//	chassis_data->wz_set=-CHASSIS_WZ_RC_SEN * gimbal_control_set->gimbal_rc_ctrl->rc.ch[CHASSIS_WZ_CHANNEL];
//	if(gimbal_control_set->gimbal_rc_ctrl->rc.s[1]==3)
//	{	
//		if(gimbal_control_set->gimbal_rc_ctrl->rc.s[0]==2)
//		{
//			chassis_flag=0;
//		}
//		else if(gimbal_control_set->gimbal_rc_ctrl->rc.s[0]==3)
//		{
//			chassis_flag=1;
//		}
//	}
//	else if(gimbal_control_set->gimbal_rc_ctrl->rc.s[1]==2)
//	{
//		if((gimbal_control_set->keyboard&KEY_PRESSED_OFFSET_Q)&&((gimbal_control_set->lastkeyboard&KEY_PRESSED_OFFSET_Q)==0))
//		{
//			chassis_flag=0;
//		}
//		else if(gimbal_control_set->keyboard&KEY_PRESSED_OFFSET_F&&(gimbal_control_set->lastkeyboard&KEY_PRESSED_OFFSET_F)==0)
//		{
//			chassis_flag++;
//			if(chassis_flag>2)
//			{
//				chassis_flag=1;
//			}
//		}
//	}
//	if(gimbal_control_set->keyboard&KEY_PRESSED_OFFSET_C&&(gimbal_control_set->lastkeyboard&KEY_PRESSED_OFFSET_C)==0)
//	{
//		turnflag=1;
//	}
//	if(gimbal_control_set->keyboard&KEY_PRESSED_OFFSET_R&&(gimbal_control_set->lastkeyboard&KEY_PRESSED_OFFSET_R)==0)
//	{
//		aimflag=!aimflag;
//	}
////	chassis_data->chassis_mode=gimbal_control_set->gimbal_rc_ctrl->rc.s[0];
//	chassis_data->chassis_mode=chassis_flag;
//	chassis_data->shoot_mode=gimbal_control_set->gimbal_rc_ctrl->mouse.press_l<<1|shoot_control.shoot_mode|aimflag<<2;
////	chassis_data->shoot_mode=gimbal_control_set->gimbal_rc_ctrl->rc.s[1];
//	chassis_data->yaw_angle=gimbal_control_set->gimbal_yaw_motor.absolute_angle;
////	chassis_data->yaw_angle=1;
//	chassis_data->yaw_gyro=gimbal_control_set->gimbal_yaw_motor.motor_gyro;
////	chassis_data->yawangle_set=yaw_angle_limit_func(chassis_data->yawangle_set-yaw_channel*YAW_RC_SEN);
//	if(chassis_data->chassis_mode==0)
//	{
//		chassis_data->yawangle_set=chassis_data->yaw_angle;
//	}

//	if(chassis_data->chassis_mode!=0&&aimflag==0&&turnflag==0)
//	{
//		chassis_data->yawangle_set-=yaw_channel*YAW_RC_SEN+gimbal_control_set->gimbal_rc_ctrl->mouse.x*YAW_MOUSE_SEN;
//	}
//	else if(chassis_data->chassis_mode!=0&&aimflag==1)
//	{	
//		if(gimbal_control_set->gimbal_yaw_motor.self_aim_yaw_angle-chassis_data->yaw_angle>0)
//		{
//			chassis_data->yawangle_set=gimbal_control_set->gimbal_yaw_motor.self_aim_yaw_angle+2;
//			//chassis_data->yawangle_set=chassis_self_aim_yaw.out+2;
//		}
//		else chassis_data->yawangle_set=gimbal_control_set->gimbal_yaw_motor.self_aim_yaw_angle;
//			
////		else if(gimbal_control_set->gimbal_yaw_motor.self_aim_yaw_angle-chassis_data->yaw_angle>0)
////		{
////			chassis_data->yawangle_set=gimbal_control_set->gimbal_yaw_motor.self_aim_yaw_angle-3;
////		}
////		chassis_data->yawangle_set=gimbal_control_set->gimbal_yaw_motor.self_aim_yaw_angle;
//	}
//	else if(chassis_data->chassis_mode!=0&&turnflag==1)
//	{
//		chassis_data->yawangle_set+=180;
//		turnflag=0;
//	}
//}

/**
  * @brief          gimbal control mode :GIMBAL_MOTOR_GYRO, use euler angle calculated by gyro sensor to control. 
  * @param[out]     gimbal_motor: yaw motor or pitch motor
  * @retval         none
  */
static void gimbal_absolute_angle_limit(gimbal_motor_t *gimbal_motor, fp32 add)
{
    static fp32 bias_angle;
    static fp32 angle_set;
	
    if (gimbal_motor == NULL)
    {
        return;
    }
//    //now angle error
//    bias_angle = rad_format((gimbal_motor->absolute_angle_set - gimbal_motor->absolute_angle)/RAD_TO_DEGREE);
//    //relative angle + angle error + add_angle > max_relative angle
//    //云台相对角度+ 误差角度 + 新增角度 如果大于 最大机械角度
//    if (gimbal_motor->relative_angle + bias_angle + add > gimbal_motor->max_relative_angle)
//    {
//        add = 0;
//    }
//    else if (gimbal_motor->relative_angle + bias_angle + add < gimbal_motor->min_relative_angle)
//    {
//        add = 0;
//    }

//		if(Flag == 0)
//		{		
////      bias_angle_yaw = inputdata.yaw  - gimbal_motor->absolute_angle;
////      gimbal_motor->absolute_angle_set += bias_angle_yaw;
//      gimbal_motor->absolute_angle_set += add ;
//			angle_limit(&(gimbal_motor->absolute_angle_set), -60.0f, 60.0f);
//			
//	//		angle_set =0;
//		}
//		else if(Flag == 1)
//		{	
////      bias_angle_pitch = inputdata.pitch  - gimbal_motor->absolute_angle;
////      gimbal_motor->absolute_angle_set += bias_angle_pitch;
//      gimbal_motor->absolute_angle_set += add ;
////			angle_limit(&(gimbal_motor->absolute_angle_set), -50.0f,+60.0f);
//	//		angle_set = -10;
//			
//		}
	angle_limit(&(add), -0.5f, 0.5f);
	if(gimbal_motor->relative_angle > gimbal_motor->max_relative_angle)
	{
		if (add < 0)   // 还想往上走
		{
			add = 0;
		}
	}
	else if(gimbal_motor->relative_angle < gimbal_motor->min_relative_angle)
	{
		if(add > 0 )
		{
			add = 0;
		}
	}
//	if(self_aim_flag !=1)
//	{
//		angle_set = gimbal_motor->absolute_angle_set;
//		gimbal_motor->absolute_angle_set = theta_format(angle_set + add);
//	}
////	
//	angle_set = gimbal_motor->absolute_angle_set;
//    gimbal_motor->absolute_angle_set = theta_format(angle_set + add);
}

/**
  * @brief          gimbal control mode :GIMBAL_MOTOR_ENCONDE, use the encode relative angle  to control. 
  * @param[out]     gimbal_motor: yaw motor or pitch motor
  * @retval         none
  */
static void gimbal_relative_angle_limit(gimbal_motor_t *gimbal_motor, fp32 add)
{
    if (gimbal_motor == NULL)
    {
        return;
    }
   angle_limit(&(add), -0.05f, 0.05f);
    //�Ƿ񳬹���� ��Сֵ
   if(gimbal_motor->relative_angle_set > gimbal_motor->max_relative_angle)
	{
		if (add > 0)   // 还想往上走
		{
			add = 0;
		}
	}
	else if(gimbal_motor->relative_angle_set < gimbal_motor->min_relative_angle)
	{
		if(add < 0)
		{
			add = 0;
		}
	}
	 angle_set = gimbal_motor->relative_angle_set;
    gimbal_motor->relative_angle_set = theta_format(angle_set + add);
}

void disable_detect(gimbal_control_t *gimbal_disable_motor)
{

	if(gimbal_disable_motor->gimbal_rc_ctrl->rc.pause == 1 || gimbal_disable_motor->gimbal_rc_ctrl->key.v == KEY_PRESSED_OFFSET_R)
	{
		disable_time ++;
		if(disable_time > 200)
		{
			disable_flag = 1;
		}
	}	
	else
	{
		disable_time=0;
		disable_flag =0;
	}
	
	if(disable_flag == 1)
	{
		CAN_dm_disable(PIT_MOTOR_ID);
		CAN_dm_disable(YAW_MOTOR_ID);
		
	}
	else return;

}

void enable_detect(gimbal_control_t *gimbal_enable_motor)
{

	if(gimbal_enable_motor->gimbal_rc_ctrl->rc.fn2 == 1 || gimbal_enable_motor->gimbal_rc_ctrl->key.v == KEY_PRESSED_OFFSET_E)
	{
		enable_time ++;
		if(enable_time > 200)
		{
			enable_flag = 1;
		}
	}	
	else
	{
		enable_time=0;
		enable_flag =0;
	}
	
	if(enable_flag == 1)
	{
		CAN_dm_enable(PIT_MOTOR_ID);
		CAN_dm_enable(YAW_MOTOR_ID);
		
	}
	else return;

}
/**
  * @brief          ���ص�������ָ�빩CAN_task����ʹ��
  * @param[out]     none
  * @retval         none
  */
 chassis_data_t *get_chassis_data_point()
{
	return &chassis_data;
}
gimbal_control_t *get_gimbal_data()
{
	return &gimbal_control;
}


void angle_limit(fp32* angle,fp32 min_angle,fp32 max_angle)
{
	if(*angle >= max_angle) *angle=max_angle;
	else if (*angle <= min_angle)  *angle=min_angle;
	
}

