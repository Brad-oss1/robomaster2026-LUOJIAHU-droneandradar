#include "main.h"
#include "shoot.h"
#include "bsp_laser.h"
#include "bsp_fric.h"
#include "CAN_receive.h"
#include "pid.h"
#include "detect_task.h"
#include "arm_math.h"
#include "Self_aim.h"


shoot_control_t shoot_control;
fp32 bullet_fre;
fp32 real_time_heat;
void trigger_control_set(void);
void shoot_feedback_update(void);
void shoot_set_mode(void);
void shoot_control_set(void);
static void trigger_motor_turn_back(void);
void trigger_control(void);
void shoot_heat_limit(void);

void shoot_Init()
{
	static const fp32 friction_speed_pid[3]={FRICTION_SPEED_PID_KP ,FRICTION_SPEED_PID_KI,FRICTION_SPEED_PID_KD};
	static const fp32 friction_current_pid[3]={FRICTION_CURRENT_PID_KP,FRICTION_CURRENT_PID_KI,FRICTION_CURRENT_PID_KD};
	PID_init(&shoot_control.friction_left_motor_speed_pid,PID_POSITION,friction_speed_pid,FRICTION_SPEED_PID_MAX_OUT,FRICTION_SPEED_PID_MAX_IOUT);
	PID_init(&shoot_control.friction_left_motor_current_pid,PID_POSITION,friction_current_pid,FRICTION_CURRENT_PID_MAX_OUT,FRICTION_CURRENT_PID_MAX_IOUT);
	PID_init(&shoot_control.friction_right_motor_speed_pid,PID_POSITION,friction_speed_pid,FRICTION_SPEED_PID_MAX_OUT,FRICTION_SPEED_PID_MAX_IOUT);
	PID_init(&shoot_control.friction_right_motor_current_pid,PID_POSITION,friction_current_pid,FRICTION_CURRENT_PID_MAX_OUT,FRICTION_CURRENT_PID_MAX_IOUT);
	
	static const fp32 Trigger_speed_pid[3] = {TRIGGER_ANGLE_PID_KP, TRIGGER_ANGLE_PID_KI, TRIGGER_ANGLE_PID_KD};
	PID_init(&shoot_control.trigger_motor_pid, PID_POSITION, Trigger_speed_pid, TRIGGER_READY_PID_MAX_OUT, TRIGGER_READY_PID_MAX_IOUT);

	shoot_control.shoot_mode= SHOOT_STOP;
	ramp_init(&shoot_control.fric_ramp,SHOOT_CONTROL_TIME * 0.001f,FRICTION_SPEED_MAX,FRICTION_SPEED_MIN);
	//rc data get
	shoot_control.shoot_rc = get_remote_control_point();
	shoot_control.trigger_motor_measure = get_trigger_motor_measure_point();
	
	shoot_control.friction_motor_measure[0]=get_left_friction_motor_measure_point();
	shoot_control.friction_motor_measure[1]=get_right_friction_motor_measure_point();
	
    shoot_control.angle = shoot_control.trigger_motor_measure->ecd * MOTOR_ECD_TO_ANGLE;
    shoot_control.trigger_given_current = 0;

    shoot_control.set_angle = shoot_control.angle;
	///init 2006motor speed is zero
    shoot_control.trigger_speed = 0.0f;
    shoot_control.trigger_speed_set = 0.0f;
	
}
void shoot_feedback_update()
{
    static fp32 speed_fliter_1 = 0.0f;
    static fp32 speed_fliter_2 = 0.0f;
    static fp32 speed_fliter_3 = 0.0f;

    //拨弹轮电机速度滤波一下
    static const fp32 fliter_num[3] = {1.725709860247969f, -0.75594777109163436f, 0.030237910843665373f};

    //二阶低通滤波
    speed_fliter_1 = speed_fliter_2;
    speed_fliter_2 = speed_fliter_3;
    speed_fliter_3 = speed_fliter_2 * fliter_num[0] + speed_fliter_1 * fliter_num[1] + (shoot_control.trigger_motor_measure->speed_rpm * MOTOR_RPM_TO_SPEED) * fliter_num[2];
    shoot_control.trigger_speed = speed_fliter_3;
	
	//rc data get	
	shoot_control.shoot_rc = get_remote_control_point();
	shoot_control.trigger_motor_measure = get_trigger_motor_measure_point();
	
	shoot_control.friction_motor_measure[0]=get_left_friction_motor_measure_point();
	shoot_control.friction_motor_measure[1]=get_right_friction_motor_measure_point();
	
	
	shoot_control.friction_left_speed=shoot_control.friction_motor_measure[0]->speed_rpm;
	shoot_control.friction_right_speed=shoot_control.friction_motor_measure[1]->speed_rpm;
	
	shoot_control.last_press_l=shoot_control.press_l;
	shoot_control.last_press_r=shoot_control.press_r;
	shoot_control.press_l=shoot_control.shoot_rc->mouse.press_l;
	shoot_control.press_r=shoot_control.shoot_rc->mouse.press_r;
}

void shoot_set_mode()
{
    static uint8_t last_trigger = 0u;
    uint8_t trigger = (uint8_t)shoot_control.shoot_rc->rc.s[SHOOT_RC_MODE_CHANNEL];

    // 扳机键或右键单击切换摩擦轮开关
    if (((trigger == 1u) && (last_trigger == 0u)) ||
        ((shoot_control.press_r == 1u) && (shoot_control.last_press_r == 0u)))
    {
        if (shoot_control.shoot_mode == SHOOT_STOP)
        {
            shoot_control.shoot_mode = SHOOT_BULLET_CONTINUE;
        }
        else
        {
            shoot_control.shoot_mode = SHOOT_STOP;
        }
    }

    last_trigger = trigger;
}


void shoot_control_set()
{
	if(shoot_control.shoot_mode==SHOOT_STOP)
	{
		laser_off();
		shoot_control.trigger_speed_set = 0;
		shoot_control.friction_speed_set = 0;
	}
	else if(shoot_control.shoot_mode==SHOOT_BULLET_CONTINUE)
	{
		bullet_fre =  10.8f;
		laser_on();
        // 先开启摩擦轮
        shoot_control.friction_speed_set = 8500.0f;
		
        // 左键按住或拨轮达到最大值且摩擦轮开启才开启拨弹
        if ((shoot_control.friction_speed_set > 0.0f) &&
            ((shoot_control.press_l == 1u) ||
             ((shoot_control.shoot_rc->rc.ch[4] + RC_CH_VALUE_OFFSET) >= (RC_CH_VALUE_MAX-50u)))
			 )
        {
												//	弹频/拨弹盘一圈弹数*60s*2006减速比
            shoot_control.trigger_speed_set = bullet_fre/9.0f*60.0f*36.0f;
            trigger_motor_turn_back();
        }
        else
        {
            shoot_control.trigger_speed_set = 0.0f;
        }
	}
	
}

void trigger_control()
{
	PID_calc(&shoot_control.trigger_motor_pid, shoot_control.trigger_speed, shoot_control.trigger_speed_set);
    shoot_control.trigger_given_current = (int16_t)(shoot_control.trigger_motor_pid.out);
}

void friction_control(void)
{
    // 左摩擦轮
    PID_calc(&shoot_control.friction_left_motor_speed_pid,
             shoot_control.friction_left_speed,
             -shoot_control.friction_speed_set);//left -
    shoot_control.friction_left_given_current = PID_calc(
             &shoot_control.friction_left_motor_current_pid,
             shoot_control.friction_motor_measure[0]->given_current,
             shoot_control.friction_left_motor_speed_pid.out);

    // 右摩擦轮
    PID_calc(&shoot_control.friction_right_motor_speed_pid,
             shoot_control.friction_right_speed,
            +shoot_control.friction_speed_set);//right +
    shoot_control.friction_right_given_current = PID_calc(
             &shoot_control.friction_right_motor_current_pid,
             shoot_control.friction_motor_measure[1]->given_current,
             shoot_control.friction_right_motor_speed_pid.out);
}


static void trigger_motor_turn_back(void)
{
    if( shoot_control.block_time < BLOCK_TIME)
    {
        shoot_control.trigger_speed_set = shoot_control.trigger_speed_set;
    }
    else
    {
        shoot_control.trigger_speed_set = -shoot_control.trigger_speed_set;
    }

    if(fabs(shoot_control.trigger_speed) < BLOCK_TRIGGER_SPEED && shoot_control.block_time < BLOCK_TIME)
    {
        shoot_control.block_time++;
        shoot_control.reverse_time = 0;
    }
    else if (shoot_control.block_time == BLOCK_TIME && shoot_control.reverse_time < REVERSE_TIME)
    {
        shoot_control.reverse_time++;
    }
    else
    {
        shoot_control.block_time = 0;
    }
}

void shoot_heat_limit(void)
{
	if(shoot_control.shoot_heat_value != shoot_control.last_shoot_heat_value)	//认为更新了
	{
		real_time_heat = shoot_control.shoot_heat_value;
	}
	else 
	{
		real_time_heat = real_time_heat + bullet_fre*0.002f*10 - shoot_control.shoot_cooling_rate*0.002f;		//我的任务间隔是0.002s
		if(real_time_heat <= 0)		{real_time_heat = 0;}
	}
	//以上保证更新没问题



	if(real_time_heat >= ((float)shoot_control.shoot_heat_limit / 2.0f))
	{
		bullet_fre = (float)(shoot_control.shoot_heat_limit - real_time_heat)/(float)shoot_control.shoot_heat_limit*20.0f;
	}
	else if((float)shoot_control.shoot_heat_limit - real_time_heat <= 18.0f)	//直接停
	{
		bullet_fre = 0;
	}
	else 
	{
		bullet_fre = 10.8f;		//维持理想弹频
	}


}

void shoot_speed_filter()
{
	
}

const shoot_control_t *shoot_control_loop()
{
	shoot_feedback_update();
	shoot_set_mode();
	shoot_control_set();
	friction_control();
	trigger_control();
	shoot_heat_limit();
//	shoot_speed_filter();
	return &shoot_control;
}
