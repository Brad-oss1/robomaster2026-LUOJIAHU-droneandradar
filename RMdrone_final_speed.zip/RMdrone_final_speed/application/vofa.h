#include "main.h"

#ifndef VOFA_ENABLE
#define VOFA_ENABLE 0
#endif

void sendfloatdata(float data[],uint8_t number);
