/**
  ****************************(C) COPYRIGHT 2019 DJI****************************
  * @file       gimbal_task.c/h
  * @brief      gimbal control task, because use the euler angle calculated by
  *             gyro sensor, range (-pi,pi), angle set-point must be in this 
  *             range.gimbal has two control mode, gyro mode and enconde mode
  *             gyro mode: use euler angle to control, encond mode: use enconde
  *             angle to control. and has some special mode:cali mode, motionless
  *             mode.
  *             云台控制任务，使用陀螺仪计算的欧拉角（范围 -pi~pi）。
  *             设定角度必须在该范围内。
  *             云台有两种控制模式：陀螺仪模式与编码器模式。
  *             陀螺仪模式：使用欧拉角进行控制；编码器模式：使用编码器角度控制。
  *             还有校准模式、停止模式等特殊状态。
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-26-2018     RM              1. done
  *  V1.1.0     Nov-11-2019     RM              1. add some annotation
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2019 DJI****************************
  */

#ifndef GIMBAL_TASK_H
#define GIMBAL_TASK_H

#include "struct_typedef.h"
#include "CAN_receive.h"
#include "pid.h"
#include "remote_control.h"
#include "shoot.h"
#include "INS_task.h"
// pitch speed close-loop PID params, max out and max iout
#define PITCH_SPEED_PID_KP        1.2f
#define PITCH_SPEED_PID_KI        0.0f
#define PITCH_SPEED_PID_KD        0.0f
#define PITCH_SPEED_PID_MAX_OUT   10.0f
#define PITCH_SPEED_PID_MAX_IOUT  2.0f

// pitch gyro angle close-loop PID params, max out and max iout
#define PITCH_GYRO_ABSOLUTE_PID_KP       0.12f // 15.0f
#define PITCH_GYRO_ABSOLUTE_PID_KI       0.0f
#define PITCH_GYRO_ABSOLUTE_PID_KD       0.0f
#define PITCH_GYRO_ABSOLUTE_PID_MAX_OUT  10.0f
#define PITCH_GYRO_ABSOLUTE_PID_MAX_IOUT 2.0f

#define PITCH_ENCODE_RELATIVE_PID_KP        8.0f
#define PITCH_ENCODE_RELATIVE_PID_KI        0.0f
#define PITCH_ENCODE_RELATIVE_PID_KD        0.0f
#define PITCH_ENCODE_RELATIVE_PID_MAX_OUT   15.0f
#define PITCH_ENCODE_RELATIVE_PID_MAX_IOUT  0.0f

// yaw speed close-loop PID params, max out and max iout
#define YAW_SPEED_PID_KP        1.0f
#define YAW_SPEED_PID_KI        0.0f
#define YAW_SPEED_PID_KD        0.0f
#define YAW_SPEED_PID_MAX_OUT   10.0f
#define YAW_SPEED_PID_MAX_IOUT  2.0f

//below r useful
// yaw encode angle close-loop PID params, max out and max iout
#define YAW_ENCODE_RELATIVE_PID_KP        5.0f
#define YAW_ENCODE_RELATIVE_PID_KI        0.0f
#define YAW_ENCODE_RELATIVE_PID_KD        0.0f
#define YAW_ENCODE_RELATIVE_PID_MAX_OUT   15.0f
#define YAW_ENCODE_RELATIVE_PID_MAX_IOUT  0.0f

// yaw gyro angle close-loop PID params, max out and max iout
#define YAW_GYRO_ABSOLUTE_PID_KP        0.07f // 26.0f
#define YAW_GYRO_ABSOLUTE_PID_KI        0.0f
#define YAW_GYRO_ABSOLUTE_PID_KD        0.001f
#define YAW_GYRO_ABSOLUTE_PID_MAX_OUT   10.0f
#define YAW_GYRO_ABSOLUTE_PID_MAX_IOUT  2.0f

// init time
#define GIMBAL_TASK_INIT_TIME 201

// yaw/pitch 通道与模式通道
#define YAW_CHANNEL   2
#define PITCH_CHANNEL 3
#define GIMBAL_MODE_CHANNEL 0
// turn 180 key
#define TURN_KEYBOARD KEY_PRESSED_OFFSET_F
// turn speed
#define TURN_SPEED    0.04f
// TEST KEY(not in use for now)
#define TEST_KEYBOARD KEY_PRESSED_OFFSET_R

// rocker value deadband
// in case when rocker in zero place but actual value isnt zero
#define RC_DEADBAND   8

// remote ctrl sensitivity
#define YAW_RC_SEN    -0.000001f
#define PITCH_RC_SEN  0.000001f // 0.005

#define YAW_MOUSE_SEN   0.00005f
#define PITCH_MOUSE_SEN 0.00015f

#define YAW_ENCODE_SEN    0.01f
#define PITCH_ENCODE_SEN  0.01f

#define GIMBAL_CONTROL_TIME 1

// test mode, 0 close, 1 open
#define GIMBAL_TEST_MODE 0

#define PITCH_TURN  0
#define YAW_TURN    1

// enconde max value and mid value
#define HALF_ECD_RANGE  4096
#define ECD_RANGE       8191
// 云台初始化：角度误差阈值、停止判断时间、初始化超时
#define GIMBAL_INIT_ANGLE_ERROR     0.1f
#define GIMBAL_INIT_STOP_TIME       100
#define GIMBAL_INIT_TIME            6000
#define GIMBAL_CALI_REDUNDANT_ANGLE 0.1f
// 云台初始化阶段的角速度与控制角度
#define GIMBAL_INIT_PITCH_SPEED     0.00004f
#define GIMBAL_INIT_YAW_SPEED       0.00005f
// init yaw/pitch motor enconde
#define INIT_YAW_SET    1.36f // realative
#define INIT_PITCH_SET  0.0f  // absolute

// 云台 yaw/pitch 机械限位角度
#define GIMBAL_YAW_MAX_RELATIVE_ANGLE  2.4f + 1.2f // rad
#define GIMBAL_YAW_MIN_RELATIVE_ANGLE  2.4f - 1.2f

#define GIMBAL_PITCH_MAX_RELATIVE_ANGLE  0.52f // +30
#define GIMBAL_PITCH_MIN_RELATIVE_ANGLE  0.00005f

// 云台校准时：电机给定值、转动时间、陀螺仪阈值
#define GIMBAL_CALI_MOTOR_SET   8000
#define GIMBAL_CALI_STEP_TIME   2000
#define GIMBAL_CALI_GYRO_LIMIT  0.1f

#define GIMBAL_CALI_PITCH_MAX_STEP  1
#define GIMBAL_CALI_PITCH_MIN_STEP  2
#define GIMBAL_CALI_YAW_MAX_STEP    3
#define GIMBAL_CALI_YAW_MIN_STEP    4

#define GIMBAL_CALI_START_STEP  GIMBAL_CALI_PITCH_MAX_STEP
#define GIMBAL_CALI_END_STEP    5

// 遥控器静止检测：在死区内保持到一定时间后回中，避免云台漂移
#define GIMBAL_MOTIONLESS_RC_DEADLINE 10
#define GIMBAL_MOTIONLESS_TIME_MAX    3000

// 编码器值转换为角度
#ifndef MOTOR_ECD_TO_RAD
#define MOTOR_ECD_TO_RAD 0.000766990394f // 2 * PI / 8192
#define RAD_TO_DEGREE 57.2957795131f
#endif
#define INS_GYRO_X_ADDRESS_OFFSET 0
#define INS_GYRO_Y_ADDRESS_OFFSET 1
#define INS_GYRO_Z_ADDRESS_OFFSET 2
#define PIT_MOTOR_ID 0x206
#define YAW_MOTOR_ID 0x205

typedef enum
{
  GIMBAL_MOTOR_OFF = 0, // 输出原始值（电机停/原始控制）
  GIMBAL_MOTOR_GYRO,    // 角度闭环（陀螺仪角度）
  GIMBAL_MOTOR_ENCONDE, // 编码器角度闭环
} gimbal_motor_mode_e;

typedef struct
{
    fp32 kp;
    fp32 ki;
    fp32 kd;

    fp32 set;
    fp32 get;
    fp32 err;

    fp32 max_out;
    fp32 max_iout;

    fp32 Pout;
    fp32 Iout;
    fp32 Dout;

    fp32 out;
} gimbal_PID_t;

typedef struct
{
    const motor_measure_t *gimbal_motor_measure;
  const dm_motor_measure_t *dm_gimbal_motor_measure;

    gimbal_PID_t gimbal_motor_absolute_angle_pid;
    gimbal_PID_t gimbal_motor_relative_angle_pid;

  pid_type_def gimbal_motor1_angle_pid;
    pid_type_def gimbal_motor_gyro_pid;

    gimbal_motor_mode_e gimbal_motor_mode;
    gimbal_motor_mode_e last_gimbal_motor_mode;

	fp32 offset_pos;
    uint16_t offset_ecd;
    fp32 max_relative_angle; //rad
    fp32 min_relative_angle; //rad

    fp32 relative_angle;     //rad
    fp32 relative_angle_set; //rad
    fp32 absolute_angle;     //rad
    fp32 absolute_angle_set; //rad
    fp32 absolute_offset_angle;//celcius
    fp32 raw_absolute_angle;//celcius
    fp32 fixed_error;//unavoidable fix problem

    fp32 motor_gyro;         //angular speed from gyro
    fp32 motor_gyro_set;
    fp32 motor_speed;        //angular speed from encoder

    fp32 raw_cmd_current;    //pid calcued(without needed limit...)
    fp32 current_set;
    int16_t given_current;   //to motor
    fp32 angle_set;          //to dm

    float self_aim_pitch_angle;
    float last_self_aim_pitch_angle;
    float self_aim_yaw_angle;
    float last_self_aim_yaw_angle;

} gimbal_motor_t;


//typedef struct
//{
//    const dm_motor_measure_t *gimbal_motor_measure;
//	
//    gimbal_PID_t gimbal_motor_absolute_angle_pid;
//    gimbal_PID_t gimbal_motor_relative_angle_pid;
//	
//	pid_type_def gimbal_motor1_angle_pid;
//    pid_type_def gimbal_motor_gyro_pid;
//	
//    gimbal_motor_mode_e gimbal_motor_mode;
//    gimbal_motor_mode_e last_gimbal_motor_mode;
//	
//    uint16_t offset_ecd;
//    fp32 max_relative_angle; //rad
//    fp32 min_relative_angle; //rad

//    fp32 relative_angle;     //rad
//    fp32 relative_angle_set; //rad
//    fp32 absolute_angle;     //rad
//    fp32 absolute_angle_set; //rad
//	
//    fp32 motor_gyro;         //angular speed from gyro
//    fp32 motor_gyro_set;
//    fp32 motor_speed;		//angular speed from encoder
//	
//    fp32 raw_cmd_current;	//pid calcued(without needed limit...)
//    fp32 current_set;
//    int16_t given_current;   //to motor
//	
//	float self_aim_pitch_angle;
//	float last_self_aim_pitch_angle;
//	float self_aim_yaw_angle;
//	float last_self_aim_yaw_angle;

//}dm_gimbal_motor_t;

typedef struct
{
    fp32 max_yaw;
    fp32 min_yaw;
    fp32 max_pitch;
    fp32 min_pitch;
    uint16_t max_yaw_ecd;
    uint16_t min_yaw_ecd;
    uint16_t max_pitch_ecd;
    uint16_t min_pitch_ecd;
    uint8_t step;
} gimbal_step_cali_t;

typedef struct
{
    const RC_ctrl_t *gimbal_rc_ctrl;
    const fp32 *gimbal_INT_angle_point;
  const fp32 *gimbal_INT_gyro_point;
    const INS_t *INS;

    gimbal_motor_t gimbal_pitch_motor;
  gimbal_motor_t gimbal_yaw_motor;
  const shoot_control_t* shoot;

    gimbal_step_cali_t gimbal_cali;
//	bool_t press_l;
//	bool_t last_press_l;
//	uint16_t keyboard;
//	uint16_t lastkeyboard;
} gimbal_control_t;


/**
  * @brief          return yaw motor data point
  * @param[in]      none
  * @retval         yaw motor data point
  */
extern const gimbal_motor_t *get_yaw_motor_point(void);
/**
  * @brief          return pitch motor data point
  * @param[in]      none
  * @retval         pitch motor data point
  */
extern const gimbal_motor_t *get_pitch_motor_point(void);

/**
  * @brief          gimbal task, osDelay GIMBAL_CONTROL_TIME (1ms)
  * @param[in]      pvParameters: null
  * @retval         none
  */

extern void gimbal_task(void const *pvParameters);
/**
  * @brief          return chassis data pointer for CAN_task
  * @param[out]     none
  * @retval         none
  */
extern chassis_data_t *get_chassis_data_point(void);
extern gimbal_control_t *get_gimbal_data(void);


#endif
