/**
  ****************************(C) COPYRIGHT 2019 DJI****************************
  * @file       remote_control.c/h
  * @brief      ң����������ң������ͨ������SBUS��Э�鴫�䣬����DMA���䷽ʽ��ԼCPU
  *             ��Դ�����ô��ڿ����ж���������������ͬʱ�ṩһЩ��������DMA������
  *             �ķ�ʽ��֤�Ȳ�ε��ȶ��ԡ�
  * @note       ��������ͨ�������ж�����������freeRTOS����
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-26-2018     RM              1. done
  *  V1.0.0     Nov-11-2019     RM              1. support development board tpye c
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2019 DJI****************************
  */

#include "remote_control.h"
#include "main.h"
#include "string.h"
#include "detect_task.h"



//ң����������������
#define RC_CHANNAL_ERROR_VALUE 700

extern UART_HandleTypeDef huart6;
extern DMA_HandleTypeDef hdma_usart6_rx;


//ȡ������
static int16_t RC_abs(int16_t value);
static uint8_t rc_new_frame_to_rc(volatile const uint8_t *frame_buf, RC_ctrl_t *rc_ctrl);
static uint8_t rc_map_switch_2bit(uint8_t value);
static uint16_t rc_get_u16(const uint8_t *buf);
static int16_t rc_get_i16(const uint8_t *buf);
static uint16_t rc_get_crc16_check_sum(uint8_t *p_msg, uint16_t len, uint16_t crc16);
static uint8_t rc_verify_crc16_check_sum(uint8_t *p_msg, uint16_t len);
/**
  * @brief          remote control protocol resolution
  * @param[in]      sbus_buf: raw data point
  * @param[out]     rc_ctrl: remote control data struct point
  * @retval         none
  */
/**
  * @brief          ң����Э�����
  * @param[in]      sbus_buf: ԭ������ָ��
  * @param[out]     rc_ctrl: ң��������ָ
  * @retval         none
  */
static void sbus_to_rc(volatile const uint8_t *sbus_buf, RC_ctrl_t *rc_ctrl);

//remote control data 
//ң�������Ʊ���
RC_ctrl_t rc_ctrl;
// 新遥控器帧标记：1=新协议帧，0=旧SBUS帧
static uint8_t rc_is_new_frame = 0u;
//����ԭʼ���ݣ�Ϊ18���ֽڣ�����36���ֽڳ��ȣ���ֹDMA����Խ��
static uint8_t sbus_rx_buf[2][SBUS_RX_BUF_NUM];


/**
  * @brief          remote control init
  * @param[in]      none
  * @retval         none
  */
/**
  * @brief          ң������ʼ��
  * @param[in]      none
  * @retval         none
  */
void remote_control_init(void)
{
    RC_Init(sbus_rx_buf[0], sbus_rx_buf[1], SBUS_RX_BUF_NUM);
}
/**
  * @brief          get remote control data point
  * @param[in]      none
  * @retval         remote control data point
  */
/**
  * @brief          ��ȡң��������ָ��
  * @param[in]      none
  * @retval         ң��������ָ��
  */
const RC_ctrl_t *get_remote_control_point(void)
{
    return &rc_ctrl;
}

//�ж�ң���������Ƿ������
uint8_t RC_data_is_error(void)
{
    //ʹ����go to��� �������ͳһ����ң�����������ݹ���
    if (RC_abs(rc_ctrl.rc.ch[0]) > RC_CHANNAL_ERROR_VALUE)
    {
        goto error;
    }
    if (RC_abs(rc_ctrl.rc.ch[1]) > RC_CHANNAL_ERROR_VALUE)
    {
        goto error;
    }
    if (RC_abs(rc_ctrl.rc.ch[2]) > RC_CHANNAL_ERROR_VALUE)
    {
        goto error;
    }
    if (RC_abs(rc_ctrl.rc.ch[3]) > RC_CHANNAL_ERROR_VALUE)
    {
        goto error;
    }
    if (rc_ctrl.rc.s[0] == 0)
    {
        goto error;
    }
    if (rc_is_new_frame)
    {
        // 新协议中 s[1] 用作触发器，合法值为 0/1
        if (rc_ctrl.rc.s[1] > 1)
        {
            goto error;
        }
    }
    else
    {
        if (rc_ctrl.rc.s[1] == 0)
        {
            goto error;
        }
    }
    return 0;

error:
    rc_ctrl.rc.ch[0] = 0;
    rc_ctrl.rc.ch[1] = 0;
    rc_ctrl.rc.ch[2] = 0;
    rc_ctrl.rc.ch[3] = 0;
    rc_ctrl.rc.ch[4] = 0;
    rc_ctrl.rc.s[0] = RC_SW_MID;
    rc_ctrl.rc.s[1] = 0;
    rc_ctrl.mouse.x = 0;
    rc_ctrl.mouse.y = 0;
    rc_ctrl.mouse.z = 0;
    rc_ctrl.mouse.press_l = 0;
    rc_ctrl.mouse.press_r = 0;
    rc_ctrl.key.v = 0;
    return 1;
}

void slove_RC_lost(void)
{
    RC_restart(SBUS_RX_BUF_NUM);
}
void slove_data_error(void)
{
    RC_restart(SBUS_RX_BUF_NUM);
}

//�����ж�
void RC_USART_IRQHandler(void)
{
    if(huart6.Instance->SR & UART_FLAG_RXNE)//���յ�����
    {
        __HAL_UART_CLEAR_PEFLAG(&huart6);
    }
    else if(USART6->SR & UART_FLAG_IDLE)
    {
        static uint16_t this_time_rx_len = 0;

        __HAL_UART_CLEAR_PEFLAG(&huart6);

        if ((hdma_usart6_rx.Instance->CR & DMA_SxCR_CT) == RESET)
        {
            /* Current memory buffer used is Memory 0 */

            //disable DMA
            //ʧЧDMA
            __HAL_DMA_DISABLE(&hdma_usart6_rx);

            //get receive data length, length = set_data_length - remain_length
            //��ȡ�������ݳ���,���� = �趨���� - ʣ�೤��
            this_time_rx_len = SBUS_RX_BUF_NUM - hdma_usart6_rx.Instance->NDTR;

            //reset set_data_lenght
            //�����趨���ݳ���
            hdma_usart6_rx.Instance->NDTR = SBUS_RX_BUF_NUM;

            //set memory buffer 1
            //�趨������1
            hdma_usart6_rx.Instance->CR |= DMA_SxCR_CT;
            
            //enable DMA
            //ʹ��DMA
            __HAL_DMA_ENABLE(&hdma_usart6_rx);

            if(this_time_rx_len == RC_FRAME_LENGTH)
            {
                sbus_to_rc(sbus_rx_buf[0], &rc_ctrl);
                //��¼���ݽ���ʱ��
                detect_hook(DBUS_TOE);
            }
            else if(this_time_rx_len == RC_NEW_FRAME_LENGTH)
            {
                if (rc_new_frame_to_rc(sbus_rx_buf[0], &rc_ctrl))
                {
                    //��¼���ݽ���ʱ��
                    detect_hook(DBUS_TOE);
                }
            }
        }
        else
        {
            /* Current memory buffer used is Memory 1 */
            //disable DMA
            //ʧЧDMA
            __HAL_DMA_DISABLE(&hdma_usart6_rx);

            //get receive data length, length = set_data_length - remain_length
            //��ȡ�������ݳ���,���� = �趨���� - ʣ�೤��
            this_time_rx_len = SBUS_RX_BUF_NUM - hdma_usart6_rx.Instance->NDTR;

            //reset set_data_lenght
            //�����趨���ݳ���
            hdma_usart6_rx.Instance->NDTR = SBUS_RX_BUF_NUM;

            //set memory buffer 0
            //�趨������0
            hdma_usart6_rx.Instance->CR &= ~(DMA_SxCR_CT);
            
            //enable DMA
            //ʹ��DMA
            __HAL_DMA_ENABLE(&hdma_usart6_rx);

            if(this_time_rx_len == RC_FRAME_LENGTH)
            {
                //����ң��������
                sbus_to_rc(sbus_rx_buf[1], &rc_ctrl);
                //��¼���ݽ���ʱ��
                detect_hook(DBUS_TOE);
            }
            else if(this_time_rx_len == RC_NEW_FRAME_LENGTH)
            {
                if (rc_new_frame_to_rc(sbus_rx_buf[1], &rc_ctrl))
                {
                    //��¼���ݽ���ʱ��
                    detect_hook(DBUS_TOE);
                }
            }
        }
    }

}

//ȡ������
static int16_t RC_abs(int16_t value)
{
    if (value > 0)
    {
        return value;
    }
    else
    {
        return -value;
    }
}

static uint16_t rc_get_u16(const uint8_t *buf)
{
    return (uint16_t)buf[0] | ((uint16_t)buf[1] << 8);
}

static int16_t rc_get_i16(const uint8_t *buf)
{
    return (int16_t)rc_get_u16(buf);
}

static uint8_t rc_map_switch_2bit(uint8_t value)
{
    switch (value & 0x03u)
    {
        case 0u: return RC_SW_LEFT;   // C: 0
        case 1u: return RC_SW_MID;  // N: 1
        case 2u: return RC_SW_RIGHT; // S: 2
        default: return RC_SW_MID;
    }
}

static const uint16_t rc_crc16_tab[256] =
{
    0x0000, 0x1189, 0x2312, 0x329b, 0x4624, 0x57ad, 0x6536, 0x74bf,
    0x8c48, 0x9dc1, 0xaf5a, 0xbed3, 0xca6c, 0xdbe5, 0xe97e, 0xf8f7,
    0x1081, 0x0108, 0x3393, 0x221a, 0x56a5, 0x472c, 0x75b7, 0x643e,
    0x9cc9, 0x8d40, 0xbfdb, 0xae52, 0xdaed, 0xcb64, 0xf9ff, 0xe876,
    0x2102, 0x308b, 0x0210, 0x1399, 0x6726, 0x76af, 0x4434, 0x55bd,
    0xad4a, 0xbcc3, 0x8e58, 0x9fd1, 0xeb6e, 0xfae7, 0xc87c, 0xd9f5,
    0x3183, 0x200a, 0x1291, 0x0318, 0x77a7, 0x662e, 0x54b5, 0x453c,
    0xbdcb, 0xac42, 0x9ed9, 0x8f50, 0xfbef, 0xea66, 0xd8fd, 0xc974,
    0x4204, 0x538d, 0x6116, 0x709f, 0x0420, 0x15a9, 0x2732, 0x36bb,
    0xce4c, 0xdfc5, 0xed5e, 0xfcd7, 0x8868, 0x99e1, 0xab7a, 0xbaf3,
    0x5285, 0x430c, 0x7197, 0x601e, 0x14a1, 0x0528, 0x37b3, 0x263a,
    0xdecd, 0xcf44, 0xfddf, 0xec56, 0x98e9, 0x8960, 0xbbfb, 0xaa72,
    0x6306, 0x728f, 0x4014, 0x519d, 0x2522, 0x34ab, 0x0630, 0x17b9,
    0xef4e, 0xfec7, 0xcc5c, 0xddd5, 0xa96a, 0xb8e3, 0x8a78, 0x9bf1,
    0x7387, 0x620e, 0x5095, 0x411c, 0x35a3, 0x242a, 0x16b1, 0x0738,
    0xffcf, 0xee46, 0xdcdd, 0xcd54, 0xb9eb, 0xa862, 0x9af9, 0x8b70,
    0x8408, 0x9581, 0xa71a, 0xb693, 0xc22c, 0xd3a5, 0xe13e, 0xf0b7,
    0x0840, 0x19c9, 0x2b52, 0x3adb, 0x4e64, 0x5fed, 0x6d76, 0x7cff,
    0x9489, 0x8500, 0xb79b, 0xa612, 0xd2ad, 0xc324, 0xf1bf, 0xe036,
    0x18c1, 0x0948, 0x3bd3, 0x2a5a, 0x5ee5, 0x4f6c, 0x7df7, 0x6c7e,
    0xa50a, 0xb483, 0x8618, 0x9791, 0xe32e, 0xf2a7, 0xc03c, 0xd1b5,
    0x2942, 0x38cb, 0x0a50, 0x1bd9, 0x6f66, 0x7eef, 0x4c74, 0x5dfd,
    0xb58b, 0xa402, 0x9699, 0x8710, 0xf3af, 0xe226, 0xd0bd, 0xc134,
    0x39c3, 0x284a, 0x1ad1, 0x0b58, 0x7fe7, 0x6e6e, 0x5cf5, 0x4d7c,
    0xc60c, 0xd785, 0xe51e, 0xf497, 0x8028, 0x91a1, 0xa33a, 0xb2b3,
    0x4a44, 0x5bcd, 0x6956, 0x78df, 0x0c60, 0x1de9, 0x2f72, 0x3efb,
    0xd68d, 0xc704, 0xf59f, 0xe416, 0x90a9, 0x8120, 0xb3bb, 0xa232,
    0x5ac5, 0x4b4c, 0x79d7, 0x685e, 0x1ce1, 0x0d68, 0x3ff3, 0x2e7a,
    0xe70e, 0xf687, 0xc41c, 0xd595, 0xa12a, 0xb0a3, 0x8238, 0x93b1,
    0x6b46, 0x7acf, 0x4854, 0x59dd, 0x2d62, 0x3ceb, 0x0e70, 0x1ff9,
    0xf78f, 0xe606, 0xd49d, 0xc514, 0xb1ab, 0xa022, 0x92b9, 0x8330,
    0x7bc7, 0x6a4e, 0x58d5, 0x495c, 0x3de3, 0x2c6a, 0x1ef1, 0x0f78
};

static uint16_t rc_get_crc16_check_sum(uint8_t *p_msg, uint16_t len, uint16_t crc16)
{
    uint8_t data;

    if (p_msg == NULL)
    {
        return 0xFFFFu;
    }

    while (len--)
    {
        data = *p_msg++;
        crc16 = ((uint16_t)crc16 >> 8) ^ rc_crc16_tab[((uint16_t)crc16 ^ (uint16_t)data) & 0x00FFu];
    }

    return crc16;
}

static uint8_t rc_verify_crc16_check_sum(uint8_t *p_msg, uint16_t len)
{
    uint16_t w_expected;

    if ((p_msg == NULL) || (len <= 2u))
    {
        return 0u;
    }

    w_expected = rc_get_crc16_check_sum(p_msg, (uint16_t)(len - 2u), 0xFFFFu);

    return (uint8_t)(((w_expected & 0xFFu) == p_msg[len - 2u]) && (((w_expected >> 8) & 0xFFu) == p_msg[len - 1u]));
}

// 解析新遥控器数据帧（参考 Example_Code_for_Data_Frame_and_Validation.c）
static uint8_t rc_new_frame_to_rc(volatile const uint8_t *frame_buf, RC_ctrl_t *rc_ctrl)
{
    uint64_t packed = 0;
    uint16_t ch0, ch1, ch2, ch3, wheel;
    uint8_t mode_sw, pause, fn1, fn2, trigger;
    uint8_t mouse_btn, mouse_left, mouse_right, mouse_middle;

    if (frame_buf == NULL || rc_ctrl == NULL)
    {
        return 0;
    }

    if (frame_buf[0] != RC_NEW_SOF_1 || frame_buf[1] != RC_NEW_SOF_2)
    {
        return 0;
    }

    if (!rc_verify_crc16_check_sum((uint8_t *)frame_buf, RC_NEW_FRAME_LENGTH))
    {
        return 0;
    }

    packed = ((uint64_t)frame_buf[2]) |
             ((uint64_t)frame_buf[3] << 8) |
             ((uint64_t)frame_buf[4] << 16) |
             ((uint64_t)frame_buf[5] << 24) |
             ((uint64_t)frame_buf[6] << 32) |
             ((uint64_t)frame_buf[7] << 40) |
             ((uint64_t)frame_buf[8] << 48) |
             ((uint64_t)frame_buf[9] << 56);

    ch0 = (uint16_t)(packed & 0x7FFu); packed >>= 11;
    ch1 = (uint16_t)(packed & 0x7FFu); packed >>= 11;
    ch2 = (uint16_t)(packed & 0x7FFu); packed >>= 11;
    ch3 = (uint16_t)(packed & 0x7FFu); packed >>= 11;
    mode_sw = (uint8_t)(packed & 0x03u); packed >>= 2;
    pause = (uint8_t)(packed & 0x01u); packed >>= 1;
    fn1 = (uint8_t)(packed & 0x01u); packed >>= 1;
    fn2 = (uint8_t)(packed & 0x01u); packed >>= 1;
    wheel = (uint16_t)(packed & 0x7FFu); packed >>= 11;
    trigger = (uint8_t)(packed & 0x01u);

    rc_ctrl->rc.ch[0] = (int16_t)ch1 - RC_CH_VALUE_OFFSET;
    rc_ctrl->rc.ch[1] = (int16_t)ch0 - RC_CH_VALUE_OFFSET;
    rc_ctrl->rc.ch[2] = (int16_t)ch3 - RC_CH_VALUE_OFFSET;
    rc_ctrl->rc.ch[3] = (int16_t)ch2 - RC_CH_VALUE_OFFSET;
    rc_ctrl->rc.ch[4] = (int16_t)wheel - RC_CH_VALUE_OFFSET;
	
	rc_ctrl->rc.pause = pause ? 1u : 0u;
	rc_ctrl->rc.fn2 = fn2 ? 1u : 0u;
	
//    // 拨杆左右方向取反（上下方向保持不变）
//    rc_ctrl->rc.ch[0] = (int16_t)(-rc_ctrl->rc.ch[0]);
//    rc_ctrl->rc.ch[2] = (int16_t)(-rc_ctrl->rc.ch[2]);

    rc_ctrl->rc.s[0] = rc_map_switch_2bit(mode_sw);
    rc_ctrl->rc.s[1] = trigger ? 1u : 0u;
    rc_is_new_frame = 1u;


    rc_ctrl->mouse.x = rc_get_i16((const uint8_t *)&frame_buf[10]);
    rc_ctrl->mouse.y = rc_get_i16((const uint8_t *)&frame_buf[12]);
    rc_ctrl->mouse.z = rc_get_i16((const uint8_t *)&frame_buf[14]);

    mouse_btn = frame_buf[16];
    mouse_left = (uint8_t)(mouse_btn & 0x03u);
    mouse_right = (uint8_t)((mouse_btn >> 2) & 0x03u);
    mouse_middle = (uint8_t)((mouse_btn >> 4) & 0x03u);

    rc_ctrl->mouse.press_l = mouse_left ? 1u : 0u;
    rc_ctrl->mouse.press_r = mouse_right ? 1u : 0u;

    rc_ctrl->key.v = rc_get_u16((const uint8_t *)&frame_buf[17]);

    // 暂未映射：pause/fn1/fn2/mouse_middle，可根据新遥控器协议补充
    (void)pause;
    (void)fn1;
    (void)fn2;
    (void)mouse_middle;

    return 1;
}
/**
  * @brief          remote control protocol resolution
  * @param[in]      sbus_buf: raw data point
  * @param[out]     rc_ctrl: remote control data struct point
  * @retval         none
  */
/**
  * @brief          ң����Э�����
  * @param[in]      sbus_buf: ԭ������ָ��
  * @param[out]     rc_ctrl: ң��������ָ
  * @retval         none
  */
static void sbus_to_rc(volatile const uint8_t *sbus_buf, RC_ctrl_t *rc_ctrl)
{
    if (sbus_buf == NULL || rc_ctrl == NULL)
    {
        return;
    }

    rc_ctrl->rc.ch[0] = (sbus_buf[0] | (sbus_buf[1] << 8)) & 0x07ff;        //!< Channel 0
    rc_ctrl->rc.ch[1] = ((sbus_buf[1] >> 3) | (sbus_buf[2] << 5)) & 0x07ff; //!< Channel 1
    rc_ctrl->rc.ch[2] = ((sbus_buf[2] >> 6) | (sbus_buf[3] << 2) |          //!< Channel 2
                         (sbus_buf[4] << 10)) &0x07ff;
    rc_ctrl->rc.ch[3] = ((sbus_buf[4] >> 1) | (sbus_buf[5] << 7)) & 0x07ff; //!< Channel 3
    rc_ctrl->rc.s[0] = ((sbus_buf[5] >> 4) & 0x0003);                  //!< Switch left
    rc_ctrl->rc.s[1] = ((sbus_buf[5] >> 4) & 0x000C) >> 2;                       //!< Switch right
    rc_ctrl->mouse.x = sbus_buf[6] | (sbus_buf[7] << 8);                    //!< Mouse X axis
    rc_ctrl->mouse.y = sbus_buf[8] | (sbus_buf[9] << 8);                    //!< Mouse Y axis
    rc_ctrl->mouse.z = sbus_buf[10] | (sbus_buf[11] << 8);                  //!< Mouse Z axis
    rc_ctrl->mouse.press_l = sbus_buf[12];                                  //!< Mouse Left Is Press ?
    rc_ctrl->mouse.press_r = sbus_buf[13];                                  //!< Mouse Right Is Press ?
    rc_ctrl->key.v = sbus_buf[14] | (sbus_buf[15] << 8);                    //!< KeyBoard value
    rc_ctrl->rc.ch[4] = sbus_buf[16] | (sbus_buf[17] << 8);                 //NULL

    rc_ctrl->rc.ch[0] -= RC_CH_VALUE_OFFSET;
    rc_ctrl->rc.ch[1] -= RC_CH_VALUE_OFFSET;
    rc_ctrl->rc.ch[2] -= RC_CH_VALUE_OFFSET;
    rc_ctrl->rc.ch[3] -= RC_CH_VALUE_OFFSET;
    rc_ctrl->rc.ch[4] -= RC_CH_VALUE_OFFSET;

//    // 左右方向取反（上下方向保持不变）
//    rc_ctrl->rc.ch[0] = (int16_t)(-rc_ctrl->rc.ch[0]);
//    rc_ctrl->rc.ch[2] = (int16_t)(-rc_ctrl->rc.ch[2]);
    rc_is_new_frame = 0u;
}

