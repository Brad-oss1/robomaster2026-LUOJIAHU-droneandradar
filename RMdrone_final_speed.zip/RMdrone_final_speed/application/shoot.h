#ifndef SHOOT_H
#define SHOOT_H
#include "CAN_receive.h"
#include "pid.h"
#include "remote_control.h"

//speed loop pid
#define FRICTION_SPEED_PID_KP        25.0f
#define FRICTION_SPEED_PID_KI        1.0f
#define FRICTION_SPEED_PID_KD        5.0f
#define FRICTION_SPEED_PID_MAX_OUT   8192.0f
#define FRICTION_SPEED_PID_MAX_IOUT  1000.0f
//current loop pid
#define FRICTION_CURRENT_PID_KP        0.7f
#define FRICTION_CURRENT_PID_KI        0.2f
#define FRICTION_CURRENT_PID_KD        0.0f
#define FRICTION_CURRENT_PID_MAX_OUT   30000.0f
#define FRICTION_CURRENT_PID_MAX_IOUT  10000.0f
//friction goal speed
#define FRICTION_SPEED_MAX 8500.0f
#define FRICTION_SPEED_MIN 0.0f
#define FRICTION_RAMP_ADD_STEP 500.0f
//left lever
#define SHOOT_RC_MODE_CHANNEL 1

#define SHOOT_CONTROL_TIME   1

//鼠标长按判断
#define PRESS_DURATION_TIME             400
//电机rmp 变化成 旋转速度的比例
#define MOTOR_RPM_TO_SPEED          0.00290888208665721596153948461415f
#define MOTOR_ECD_TO_ANGLE          0.000021305288720633905968306772076277f
#define FULL_COUNT                  18
//SPEED SET
#define SINGLE_TRIGGER_SPEED        200.0f
#define CONTINUE_TRIGGER_SPEED      40.0f

//FRICTION MOTOR SPEED
#define MAX_FRICTION_SPEED 8500.0f
//卡单时间 以及反转时间
#define BLOCK_TRIGGER_SPEED         1.0f//卡弹旋转速度
#define BLOCK_TIME                  700
#define REVERSE_TIME                500
#define REVERSE_SPEED_LIMIT         13.0f

#define PI_FOUR                     0.78539816339744830961566084581988f
#define PI_TEN                      0.314f

//拨弹轮电机PID
#define TRIGGER_ANGLE_PID_KP        800.0f
#define TRIGGER_ANGLE_PID_KI        0.5f
#define TRIGGER_ANGLE_PID_KD        0.0f

#define TRIGGER_BULLET_PID_MAX_OUT  10000.0f
#define TRIGGER_BULLET_PID_MAX_IOUT 9000.0f

#define TRIGGER_READY_PID_MAX_OUT   10000.0f
#define TRIGGER_READY_PID_MAX_IOUT  7000.0f


#define SHOOT_HEAT_REMAIN_VALUE     80
typedef enum
{
    SHOOT_STOP = 0,
	SHOOT_BULLET_CONTINUE,
} shoot_mode_e;

typedef struct
{
	const motor_measure_t *trigger_motor_measure;
	const motor_measure_t *friction_motor_measure[2];
	
	const RC_ctrl_t *shoot_rc;
	
	pid_type_def friction_left_motor_speed_pid; 
	pid_type_def friction_left_motor_current_pid; 
	pid_type_def friction_right_motor_speed_pid; 
	pid_type_def friction_right_motor_current_pid; 

	pid_type_def trigger_motor_pid;
	
	shoot_mode_e shoot_mode;
	ramp_function_source_t fric_ramp;
	
	fp32 friction_left_speed;
	fp32 friction_right_speed;
    fp32 friction_speed_set;	
	int16_t friction_left_given_current;
	int16_t friction_right_given_current;
	
	fp32 trigger_speed_set;//�������ٶ�
	fp32 trigger_speed;
    int16_t trigger_given_current;
	//防堵转
	uint16_t block_time;
    uint16_t reverse_time;
    bool_t move_flag;
		
    fp32 angle;
	fp32 set_angle;
    int8_t ecd_count;
	
	bool_t press_l;
    bool_t press_r;
    bool_t last_press_l;
    bool_t last_press_r;
	
	uint16_t shoot_heat_limit;
	uint16_t shoot_heat_value;
	uint16_t shoot_cooling_rate;
	uint16_t last_shoot_heat_value;
}shoot_control_t;

void shoot_Init(void);
const shoot_control_t* shoot_control_loop(void);
extern shoot_control_t shoot_control;
#endif
