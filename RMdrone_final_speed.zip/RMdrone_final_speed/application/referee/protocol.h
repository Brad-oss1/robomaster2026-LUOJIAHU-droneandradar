#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdint.h>

#define HEADER_SOF 0xA5

#define REF_PROTOCOL_HEADER_SIZE 5
#define REF_PROTOCOL_CMD_SIZE 2
#define REF_PROTOCOL_CRC16_SIZE 2
#define REF_HEADER_CRC_CMDID_LEN (REF_PROTOCOL_HEADER_SIZE + REF_PROTOCOL_CMD_SIZE + REF_PROTOCOL_CRC16_SIZE)
#define REF_PROTOCOL_FRAME_MAX_SIZE 128

typedef __packed struct
{
    uint8_t SOF;
    uint16_t data_length;
    uint8_t seq;
    uint8_t CRC8;
} frame_header_struct_t;

typedef enum
{
    STEP_HEADER_SOF = 0,
    STEP_LENGTH_LOW,
    STEP_LENGTH_HIGH,
    STEP_FRAME_SEQ,
    STEP_HEADER_CRC8,
    STEP_DATA_CRC16
} unpack_step_e;

typedef struct
{
    uint8_t unpack_step;
    uint16_t index;
    uint16_t data_len;
    uint8_t protocol_packet[REF_PROTOCOL_FRAME_MAX_SIZE];
} unpack_data_t;

#define GAME_STATE_CMD_ID 0x0001
#define GAME_RESULT_CMD_ID 0x0002
#define GAME_ROBOT_HP_CMD_ID 0x0003
#define FIELD_EVENTS_CMD_ID 0x0101
#define REFEREE_WARNING_CMD_ID 0x0104
#define ROBOT_STATE_CMD_ID 0x0201
#define POWER_HEAT_DATA_CMD_ID 0x0202
#define ROBOT_POS_CMD_ID 0x0203
#define BUFF_MUSK_CMD_ID 0x0204
#define ROBOT_HURT_CMD_ID 0x0206
#define SHOOT_DATA_CMD_ID 0x0207
#define BULLET_REMAINING_CMD_ID 0x0208
#define RFID_STATUS_CMD_ID 0x0209
#define STUDENT_INTERACTIVE_DATA_CMD_ID 0x0301

#endif
