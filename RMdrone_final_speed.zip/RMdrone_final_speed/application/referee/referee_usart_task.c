/**
 * @file referee_usart_task.c
 * @brief RM裁判系统数据处理
 * ----------------------------------------------------------------------------
 * @version 1.0.0.0
 * @author RM
 * @date 2018-12-26
 * @remark 官步初始代码
 * ----------------------------------------------------------------------------
 * @version 1.0.0.1
 * @author 周明杨
 * @date 2024-12-30
 * @remark 优化整体架构
 */

/*-----------------------------------头文件引用-----------------------------------*/

#include "referee_usart_task.h"
#include "main.h"
#include "cmsis_os.h"
#include "stm32f4xx_hal.h"
#include "detect_task.h"
#include "CRC8_CRC16.h"
#include "fifo.h"
#include "protocol.h"
#include "referee.h"
#include "gimbal_task.h"
#include "string.h"
#include "ui.h"
#include "usart.h"
#include "bsp_usart.h"

/*-----------------------------------变量声明-----------------------------------*/

// 裁判系统绑定到串口1
extern UART_HandleTypeDef huart1;
static uint8_t usart1_buf[2][USART_RX_BUF_LENGTH];

// 裁判系统数据
fifo_s_t referee_fifo;
// 裁判系统数据缓冲区
uint8_t referee_fifo_buf[REFEREE_FIFO_BUF_LENGTH];
// 裁判系统消息标准结构，用于解包裁判系统消息
unpack_data_t referee_unpack_obj;

uint32_t ui_fpsTick; // 刷新计数
uint32_t ui_period = 100;
uint32_t ui_initTick_1; // 重新初始化绘制计数（解决丢包导致静态图案丢失）
uint32_t ui_initTick_2;
uint32_t ui_initTick_3;
extern uint32_t uwTick;

// 底盘任务控制的小陀螺标识符：0-关闭，1-正转，2-反转
extern uint8_t rotate_flag;
// 摩擦轮状态标识符：0-关闭，1-开启中，2-弹药准备就绪，3-射击准备就绪，4-射击中
extern uint8_t fric_flag;
// 自瞄标识符：0-关闭，1-开启
extern uint8_t autoaim_flag;
// 云台数据，其中有当前pitch角度、当前yaw角度
extern gimbal_control_t gimbal_control_1;
// 裁判系统数据
extern ext_game_robot_state_t robot_state;        // 机器人状态
extern ext_power_heat_data_t power_heat_data_t;   // 功率与热量
extern ext_bullet_remaining_t bullet_remaining_t; // 剩余弹药量
extern ext_rfid_status_t rfid_status;

extern int ui_self_id;

/*-----------------------------------内部函数声明-----------------------------------*/

/**
 * @brief 单字节解包
 * @param none
 * @retval none
 */
static void referee_unpack_fifo_data(void);

/*-----------------------------------函数实现-----------------------------------*/

void referee_usart_task(void const *argument)
{
  // 初始化裁判系统数据结构体
  init_referee_struct_data();
  // 初始化fifo序列
  fifo_s_init(&referee_fifo, referee_fifo_buf, REFEREE_FIFO_BUF_LENGTH);
  // 初始化usart1双DMA接收
  usart1_init(usart1_buf[0], usart1_buf[1], USART_RX_BUF_LENGTH);
  osDelay(10);
  // 初始化图像数据（当前工程使用 ui_g 自动生成接口）
  ui_init_g_Ungroup();

  while (1)
  {
    ui_self_id = robot_state.robot_id;
    referee_unpack_fifo_data();
    osDelay(10);
    // 按固定周期刷新 UI
    if ((uwTick - ui_fpsTick) > ui_period)
    {
      ui_fpsTick = uwTick;
      ui_update_g_Ungroup();
    }
  }
}

void referee_unpack_fifo_data(void)
{
  uint8_t byte = 0;
  uint8_t sof = HEADER_SOF;
  unpack_data_t *p_obj = &referee_unpack_obj;

  while (fifo_s_used(&referee_fifo))
  {
    byte = fifo_s_get(&referee_fifo);
    switch (p_obj->unpack_step)
    {
    case STEP_HEADER_SOF:
    {
      if (byte == sof)
      {
        p_obj->unpack_step = STEP_LENGTH_LOW;
        p_obj->protocol_packet[p_obj->index++] = byte;
      }
      else
      {
        p_obj->index = 0;
      }
    }
    break;

    case STEP_LENGTH_LOW:
    {
      p_obj->data_len = byte;
      p_obj->protocol_packet[p_obj->index++] = byte;
      p_obj->unpack_step = STEP_LENGTH_HIGH;
    }
    break;

    case STEP_LENGTH_HIGH:
    {
      p_obj->data_len |= (byte << 8);
      p_obj->protocol_packet[p_obj->index++] = byte;

      if (p_obj->data_len < (REF_PROTOCOL_FRAME_MAX_SIZE - REF_HEADER_CRC_CMDID_LEN))
      {
        p_obj->unpack_step = STEP_FRAME_SEQ;
      }
      else
      {
        p_obj->unpack_step = STEP_HEADER_SOF;
        p_obj->index = 0;
      }
    }
    break;
    case STEP_FRAME_SEQ:
    {
      p_obj->protocol_packet[p_obj->index++] = byte;
      p_obj->unpack_step = STEP_HEADER_CRC8;
    }
    break;

    case STEP_HEADER_CRC8:
    {
      p_obj->protocol_packet[p_obj->index++] = byte;

      if (p_obj->index == REF_PROTOCOL_HEADER_SIZE)
      {
        if (verify_CRC8_check_sum(p_obj->protocol_packet, REF_PROTOCOL_HEADER_SIZE))
        {
          p_obj->unpack_step = STEP_DATA_CRC16;
        }
        else
        {
          p_obj->unpack_step = STEP_HEADER_SOF;
          p_obj->index = 0;
        }
      }
    }
    break;

    case STEP_DATA_CRC16:
    {
      if (p_obj->index < (REF_HEADER_CRC_CMDID_LEN + p_obj->data_len))
      {
        p_obj->protocol_packet[p_obj->index++] = byte;
      }
      if (p_obj->index >= (REF_HEADER_CRC_CMDID_LEN + p_obj->data_len))
      {
        p_obj->unpack_step = STEP_HEADER_SOF;
        p_obj->index = 0;

        if (verify_CRC16_check_sum(p_obj->protocol_packet, REF_HEADER_CRC_CMDID_LEN + p_obj->data_len))
        {
          referee_data_solve(p_obj->protocol_packet);
        }
      }
    }
    break;

    default:
    {
      p_obj->unpack_step = STEP_HEADER_SOF;
      p_obj->index = 0;
    }
    break;
    }
  }
}

void Referee_USART_IRQHandler(void)
{
  static uint16_t this_time_rx_len = 0;

  if (USART1->SR & UART_FLAG_IDLE)
  {
    __HAL_UART_CLEAR_PEFLAG(&huart1);

    if ((huart1.hdmarx->Instance->CR & DMA_SxCR_CT) == RESET)
    {
      __HAL_DMA_DISABLE(huart1.hdmarx);
      this_time_rx_len = USART_RX_BUF_LENGTH - __HAL_DMA_GET_COUNTER(huart1.hdmarx);
      __HAL_DMA_SET_COUNTER(huart1.hdmarx, USART_RX_BUF_LENGTH);
      huart1.hdmarx->Instance->CR |= DMA_SxCR_CT;
      __HAL_DMA_ENABLE(huart1.hdmarx);
      fifo_s_puts(&referee_fifo, (char *)usart1_buf[0], this_time_rx_len);
      detect_hook(REFEREE_TOE);
    }
    else
    {
      __HAL_DMA_DISABLE(huart1.hdmarx);
      this_time_rx_len = USART_RX_BUF_LENGTH - __HAL_DMA_GET_COUNTER(huart1.hdmarx);
      __HAL_DMA_SET_COUNTER(huart1.hdmarx, USART_RX_BUF_LENGTH);
      huart1.hdmarx->Instance->CR &= ~(DMA_SxCR_CT);
      __HAL_DMA_ENABLE(huart1.hdmarx);
      fifo_s_puts(&referee_fifo, (char *)usart1_buf[1], this_time_rx_len);
      detect_hook(REFEREE_TOE);
    }
  }
}
