//
// Created by RM UI Designer
// Static Edition
//

#include <string.h>

#include "ui_interface.h"

ui_2_frame_t ui_g_Ungroup_0;

ui_interface_line_t *ui_g_Ungroup_y = (ui_interface_line_t*)&(ui_g_Ungroup_0.data[0]);
ui_interface_line_t *ui_g_Ungroup_x = (ui_interface_line_t*)&(ui_g_Ungroup_0.data[1]);

void _ui_init_g_Ungroup_0() {
    for (int i = 0; i < 2; i++) {
        ui_g_Ungroup_0.data[i].figure_name[0] = 0;
        ui_g_Ungroup_0.data[i].figure_name[1] = 0;
        ui_g_Ungroup_0.data[i].figure_name[2] = i + 0;
        ui_g_Ungroup_0.data[i].operate_type = 1;
    }
    for (int i = 2; i < 2; i++) {
        ui_g_Ungroup_0.data[i].operate_type = 0;
    }

    ui_g_Ungroup_y->figure_type = 0;
    ui_g_Ungroup_y->operate_type = 1;
    ui_g_Ungroup_y->layer = 0;
    ui_g_Ungroup_y->color = 2;
    ui_g_Ungroup_y->start_x = 940;
    ui_g_Ungroup_y->start_y = 566;
    ui_g_Ungroup_y->width = 2;
    ui_g_Ungroup_y->end_x = 1020;
    ui_g_Ungroup_y->end_y = 566;

    ui_g_Ungroup_x->figure_type = 0;
    ui_g_Ungroup_x->operate_type = 1;
    ui_g_Ungroup_x->layer = 0;
    ui_g_Ungroup_x->color = 2;
    ui_g_Ungroup_x->start_x = 980;
    ui_g_Ungroup_x->start_y = 400;
    ui_g_Ungroup_x->width = 3;
    ui_g_Ungroup_x->end_x = 980;
    ui_g_Ungroup_x->end_y = 597;


    ui_proc_2_frame(&ui_g_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Ungroup_0, sizeof(ui_g_Ungroup_0));
}

void _ui_update_g_Ungroup_0() {
    for (int i = 0; i < 2; i++) {
        ui_g_Ungroup_0.data[i].operate_type = 2;
    }

    ui_proc_2_frame(&ui_g_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Ungroup_0, sizeof(ui_g_Ungroup_0));
}

void _ui_remove_g_Ungroup_0() {
    for (int i = 0; i < 2; i++) {
        ui_g_Ungroup_0.data[i].operate_type = 3;
    }

    ui_proc_2_frame(&ui_g_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Ungroup_0, sizeof(ui_g_Ungroup_0));
}


void ui_init_g_Ungroup() {
    _ui_init_g_Ungroup_0();
}

void ui_update_g_Ungroup() {
    _ui_update_g_Ungroup_0();
}

void ui_remove_g_Ungroup() {
    _ui_remove_g_Ungroup_0();
}

