//
// Created by RM UI Designer
// Static Edition
//

#ifndef UI_g_H
#define UI_g_H

#include "ui_interface.h"

extern ui_interface_line_t *ui_g_Ungroup_y;
extern ui_interface_line_t *ui_g_Ungroup_x;

void ui_init_g_Ungroup(void);
void ui_update_g_Ungroup(void);
void ui_remove_g_Ungroup(void);


#endif // UI_g_H
